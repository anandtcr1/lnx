import os
import shutil
from functools import lru_cache

from app.core.config import settings
from app.storage.base import StorageProvider


class LocalStorageProvider(StorageProvider):
    """Filesystem storage rooted at STORAGE_PATH with traversal protection."""

    def __init__(self, root: str | None = None) -> None:
        self.root = os.path.abspath(root or settings.STORAGE_PATH)
        for sub in ("uploads", "processed", "exports"):
            os.makedirs(os.path.join(self.root, sub), exist_ok=True)

    def _abs(self, key: str) -> str:
        candidate = os.path.abspath(os.path.join(self.root, key))
        if not candidate.startswith(self.root + os.sep) and candidate != self.root:
            raise ValueError("Invalid storage key (path traversal).")
        return candidate

    def save(self, key: str, data: bytes) -> str:
        dest = self._abs(key)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as fh:
            fh.write(data)
        return dest

    def path_for(self, key: str) -> str:
        return self._abs(key)

    def exists(self, key: str) -> bool:
        return os.path.exists(self._abs(key))

    def delete(self, key: str) -> None:
        path = self._abs(key)
        if os.path.isfile(path):
            os.remove(path)

    def delete_prefix(self, prefix: str) -> None:
        path = self._abs(prefix)
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)


@lru_cache
def get_storage() -> LocalStorageProvider:
    return LocalStorageProvider()

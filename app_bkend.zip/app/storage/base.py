from abc import ABC, abstractmethod


class StorageProvider(ABC):
    """Storage abstraction. Implement this interface to add S3, Cloudflare R2,
    Supabase Storage, MinIO or Azure Blob Storage backends."""

    @abstractmethod
    def save(self, key: str, data: bytes) -> str:
        """Store bytes under `key`, return the provider path."""
        raise NotImplementedError

    @abstractmethod
    def path_for(self, key: str) -> str:
        """Return an absolute local path for `key` (fetching remotely if needed)."""
        raise NotImplementedError

    @abstractmethod
    def exists(self, key: str) -> bool:
        raise NotImplementedError

    @abstractmethod
    def delete(self, key: str) -> None:
        raise NotImplementedError

    @abstractmethod
    def delete_prefix(self, prefix: str) -> None:
        raise NotImplementedError

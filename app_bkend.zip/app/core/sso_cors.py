"""CORS for the Windows sign-in endpoint.

The frontend calls /auth/sso with `credentials: "include"` so the browser
attaches the user's Kerberos ticket. A credentialed response must name one
explicit origin — and only trusted ones: if any origin were accepted, any
website an employee visits could silently mint a session for them. The global
CORSMiddleware answers "*" (unusable with credentials), so this outer
middleware rewrites the headers for the SSO path only, using CORS_ORIGINS.
"""

from starlette.datastructures import Headers, MutableHeaders
from starlette.types import ASGIApp, Message, Receive, Scope, Send


class SSOCorsMiddleware:
    def __init__(self, app: ASGIApp, paths: set[str], trusted_origins: list[str]) -> None:
        self.app = app
        self.paths = paths
        self.trusted = set(trusted_origins)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope["path"] not in self.paths:
            await self.app(scope, receive, send)
            return
        origin = Headers(scope=scope).get("origin")

        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers = MutableHeaders(scope=message)
                for name in ("access-control-allow-origin", "access-control-allow-credentials"):
                    if name in headers:
                        del headers[name]
                if origin and origin in self.trusted:
                    headers["Access-Control-Allow-Origin"] = origin
                    headers["Access-Control-Allow-Credentials"] = "true"
                    headers.add_vary_header("Origin")
            await send(message)

        await self.app(scope, receive, send_wrapper)

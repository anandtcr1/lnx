"""In-process outbound network guard for offline / air-gapped operation.

When NETWORK_ACCESS=false, every socket connect() to a non-private address
raises NetworkAccessBlocked immediately. Private ranges stay allowed so the
API can still talk to PostgreSQL/Redis inside the Docker network. This turns
any accidental model download into a fast, explicit error instead of a hang.
"""

import ipaddress
import os
import socket
from typing import Any

_ALLOWED_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
]

_installed = False
_original_connect = socket.socket.connect
_original_connect_ex = socket.socket.connect_ex


class NetworkAccessBlocked(OSError):
    """Raised when code tries to reach a public network while NETWORK_ACCESS=false."""


def _ip_allowed(ip: ipaddress._BaseAddress) -> bool:
    return any(ip in net for net in _ALLOWED_NETWORKS)


def allow_host(host: str) -> None:
    """Trust the current IPs of one explicitly configured host (e.g. the AD domain controller).

    Resolved on every call so DNS changes are picked up; unresolvable hosts are ignored
    (the subsequent connect fails with a normal DNS error).
    """
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if not _ip_allowed(ip):
            _ALLOWED_NETWORKS.append(ipaddress.ip_network(ip))


def host_allowed(host: str) -> bool:
    try:
        return _ip_allowed(ipaddress.ip_address(host))
    except ValueError:
        pass
    if host in ("localhost",):
        return True
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return False
    ips = {info[4][0] for info in infos}
    if not ips:
        return False
    return all(_ip_allowed(ipaddress.ip_address(ip.split("%")[0])) for ip in ips)


def _check(address: Any) -> None:
    if isinstance(address, tuple) and address:
        host = address[0]
        if isinstance(host, str) and host and not host_allowed(host):
            raise NetworkAccessBlocked(
                f"Outbound network access is disabled (NETWORK_ACCESS=false); refused connection to {host}"
            )


def _guarded_connect(self: socket.socket, address: Any) -> None:
    _check(address)
    return _original_connect(self, address)


def _guarded_connect_ex(self: socket.socket, address: Any) -> int:
    _check(address)
    return _original_connect_ex(self, address)


def install() -> None:
    """Activate the guard (idempotent) and set library-level offline switches."""
    global _installed
    if _installed:
        return
    socket.socket.connect = _guarded_connect  # type: ignore[method-assign]
    socket.socket.connect_ex = _guarded_connect_ex  # type: ignore[method-assign]
    # Library-level switches honoured by common ML tooling.
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
    os.environ.setdefault("NO_ALBUMENTATIONS_UPDATE", "1")
    _installed = True


def is_installed() -> bool:
    return _installed

import json
import os
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, Response
from sqlalchemy.orm import Session, selectinload

from app.core.config import settings
from app.core.database import get_db
from app.core.errors import OCRError
from app.core.security import require_auth
from app.models.models import OCRJob, OCRPage, OCRRegion
from app.schemas import schemas
from app.services import export_service, ocr_service

router = APIRouter(prefix="/ocr", tags=["ocr"], dependencies=[Depends(require_auth)])


def _job_or_404(db: Session, job_id: str) -> OCRJob:
    job = (
        db.query(OCRJob)
        .options(
            selectinload(OCRJob.pages).selectinload(OCRPage.blocks),
            selectinload(OCRJob.regions),
        )
        .filter(OCRJob.id == job_id)
        .first()
    )
    if job is None:
        raise HTTPException(status_code=404, detail="OCR job not found.")
    return job


def _to_detail(job: OCRJob, request: Request) -> schemas.JobDetail:
    base = str(request.base_url).rstrip("/")
    detail = schemas.JobDetail.model_validate(job)
    for page_out, page in zip(detail.pages, job.pages):
        page_out.image_url = f"{base}/api/v1/ocr/{job.id}/pages/{page.page_number}/image"
    return detail


@router.post("", response_model=schemas.JobCreated, status_code=202)
async def create_ocr_job(
    file: UploadFile = File(...),
    options: Optional[str] = Form(default=None),
    engine: Optional[str] = Form(default=None),
    language: Optional[str] = Form(default=None),
    document_type: Optional[str] = Form(default=None),
    quality_mode: Optional[str] = Form(default=None),
    prefer_quality: Optional[bool] = Form(default=None),
    device_preference: Optional[str] = Form(default=None),
    deskew: Optional[bool] = Form(default=None),
    denoise: Optional[bool] = Form(default=None),
    auto_rotate: Optional[bool] = Form(default=None),
    enhance_contrast: Optional[bool] = Form(default=None),
    detect_tables: Optional[bool] = Form(default=None),
    structured_extraction: Optional[bool] = Form(default=None),
    preserve_layout: Optional[bool] = Form(default=None),
    preserve_diacritics: Optional[bool] = Form(default=None),
    preserve_punctuation: Optional[bool] = Form(default=None),
    handwriting_detection: Optional[bool] = Form(default=None),
    db: Session = Depends(get_db),
):
    """Upload a document (JPG/PNG/WEBP/TIFF/BMP/PDF) and queue OCR. Fully offline."""
    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Empty file.")

    filename = os.path.basename(file.filename or "upload")
    mime = file.content_type or "application/octet-stream"

    # Merge the JSON `options` blob with individual form fields (fields win).
    opts: dict = {}
    if options:
        try:
            opts = json.loads(options)
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid JSON in 'options'.")
    for key, value in {
        "engine": engine,
        "language": language,
        "document_type": document_type,
        "quality_mode": quality_mode,
        "prefer_quality": prefer_quality,
        "device_preference": device_preference,
        "deskew": deskew,
        "denoise": denoise,
        "auto_rotate": auto_rotate,
        "enhance_contrast": enhance_contrast,
        "detect_tables": detect_tables,
        "structured_extraction": structured_extraction,
        "preserve_layout": preserve_layout,
        "preserve_diacritics": preserve_diacritics,
        "preserve_punctuation": preserve_punctuation,
        "handwriting_detection": handwriting_detection,
    }.items():
        if value is not None:
            opts[key] = value
    opts = schemas.OCROptions.model_validate(opts).model_dump()  # reject bad values early, fill defaults

    try:
        stored_filename, _ = ocr_service.save_upload(filename, data, mime)
    except OCRError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error_code": exc.code.value, "message": exc.public_message(settings.is_development)},
        )

    job = ocr_service.create_job(db, filename, mime, stored_filename, opts)

    try:
        ocr_service.enqueue_processing(job.id)
    except Exception as exc:
        job.status = "failed"
        job.error = f"Could not queue OCR job: {exc}"
        db.commit()
        raise HTTPException(status_code=503, detail="OCR queue unavailable. Is the worker/Redis running?")

    return schemas.JobCreated(job_id=job.id, status=job.status)


@router.get("", response_model=schemas.JobList)
def list_ocr_jobs(
    status: Optional[str] = Query(default=None),
    q: Optional[str] = Query(default=None),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
):
    query = db.query(OCRJob)
    if status:
        query = query.filter(OCRJob.status == status)
    if q:
        query = query.filter(OCRJob.filename.ilike(f"%{q}%"))
    total = query.count()
    items = query.order_by(OCRJob.created_at.desc()).offset(offset).limit(limit).all()
    return schemas.JobList(
        items=[schemas.JobSummary.model_validate(j) for j in items],
        total=total,
    )


@router.get("/{job_id}", response_model=schemas.JobDetail)
def get_ocr_job(job_id: str, request: Request, db: Session = Depends(get_db)):
    return _to_detail(_job_or_404(db, job_id), request)


@router.patch("/{job_id}", response_model=schemas.JobDetail)
def update_ocr_job(job_id: str, payload: schemas.JobUpdate, request: Request, db: Session = Depends(get_db)):
    """Save manually edited OCR text (whole document and/or per page)."""
    job = _job_or_404(db, job_id)
    if payload.text is not None:
        job.text = payload.text
    if payload.pages:
        by_number = {p.page_number: p for p in job.pages}
        for update in payload.pages:
            page = by_number.get(update.page_number)
            if page is not None:
                page.text = update.text
    db.commit()
    db.refresh(job)
    return _to_detail(job, request)


@router.delete("/{job_id}", status_code=204)
def delete_ocr_job(job_id: str, db: Session = Depends(get_db)):
    job = db.get(OCRJob, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="OCR job not found.")
    ocr_service.delete_job_files(job)
    db.delete(job)
    db.commit()
    return Response(status_code=204)


@router.post("/{job_id}/reprocess", response_model=schemas.JobCreated, status_code=202)
def reprocess_ocr_job(job_id: str, payload: schemas.ReprocessRequest, db: Session = Depends(get_db)):
    job = db.get(OCRJob, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="OCR job not found.")
    ocr_service.reset_for_reprocess(db, job, payload.engine)
    ocr_service.enqueue_processing(job.id)
    return schemas.JobCreated(job_id=job.id, status="pending")


@router.get("/{job_id}/file")
def get_original_file(job_id: str, db: Session = Depends(get_db)):
    job = db.get(OCRJob, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="OCR job not found.")
    path = ocr_service.get_storage().path_for(f"uploads/{job.stored_filename}")
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Stored file missing.")
    return FileResponse(path, media_type=job.mime_type, filename=job.filename)


@router.get("/{job_id}/pages/{page_number}/image")
def get_page_image(job_id: str, page_number: int, db: Session = Depends(get_db)):
    page = (
        db.query(OCRPage)
        .filter(OCRPage.job_id == job_id, OCRPage.page_number == page_number)
        .first()
    )
    if page is None or not page.image_path:
        raise HTTPException(status_code=404, detail="Page image not found.")
    path = ocr_service.get_storage().path_for(page.image_path)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Page image missing on disk.")
    return FileResponse(path, media_type="image/png")


@router.get("/{job_id}/export")
def export_ocr_job(
    job_id: str,
    format: str = Query(default="txt", pattern="^(txt|json|csv)$"),
    db: Session = Depends(get_db),
):
    job = _job_or_404(db, job_id)
    stem = os.path.splitext(job.filename)[0] or "ocr_result"
    if format == "txt":
        content = export_service.job_to_txt(job)
        media, ext = "text/plain; charset=utf-8", "txt"
    elif format == "json":
        content = export_service.job_to_json(job)
        media, ext = "application/json; charset=utf-8", "json"
    else:
        content = export_service.job_to_csv(job)
        media, ext = "text/csv; charset=utf-8", "csv"
    return Response(
        content=content.encode("utf-8"),
        media_type=media,
        headers={"Content-Disposition": f'attachment; filename="{stem}.{ext}"'},
    )

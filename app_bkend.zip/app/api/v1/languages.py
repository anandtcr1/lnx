from fastapi import APIRouter, Depends

from app.core.security import require_auth
from app.schemas import schemas
from app.services.languages import all_languages

router = APIRouter(prefix="/languages", tags=["languages"], dependencies=[Depends(require_auth)])


@router.get("", response_model=list[schemas.LanguageInfo])
def list_languages():
    """Supported OCR languages, with the engines that cover each one."""
    return [lang.to_dict() for lang in all_languages()]

from fastapi import APIRouter, Depends

from app.core.security import require_auth
from app.providers.ocr import engine_statuses
from app.schemas import schemas

router = APIRouter(prefix="/engines", tags=["engines"], dependencies=[Depends(require_auth)])


@router.get("", response_model=list[schemas.EngineInfo])
def list_engines():
    """Registered OCR engines with local-model status (READY / MODEL_NOT_INSTALLED / ...)."""
    return engine_statuses()

import uuid
from datetime import datetime, timezone

import sqlalchemy as sa
from sqlalchemy.orm import relationship

from app.core.database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id = sa.Column(sa.String(36), primary_key=True, default=_uuid)
    # username is the login identifier; email is optional metadata (kept nullable
    # because the table predates login and may have been created without it).
    username = sa.Column(sa.String(128), unique=True, nullable=True, index=True)
    email = sa.Column(sa.String(255), unique=True, nullable=True, index=True)
    hashed_password = sa.Column(sa.String(255), nullable=False)
    is_admin = sa.Column(sa.Boolean, nullable=False, default=False)
    # "local" = password checked here (first-run admin / local users); "ldap" = checked by AD.
    auth_source = sa.Column(sa.String(16), nullable=True, default="ldap")
    display_name = sa.Column(sa.String(255), nullable=True)
    # False = disabled by an admin: cannot sign in, existing sessions stop working.
    # Users are never deleted, only disabled (and can be enabled again).
    is_active = sa.Column(sa.Boolean, nullable=True, default=True)
    created_at = sa.Column(sa.DateTime(timezone=True), default=_utcnow)

    @property
    def enabled(self) -> bool:
        # NULL = row created before the column existed -> active.
        return self.is_active is not False


class Document(Base):
    __tablename__ = "documents"

    id = sa.Column(sa.String(36), primary_key=True, default=_uuid)
    filename = sa.Column(sa.String(512), nullable=False)
    stored_path = sa.Column(sa.String(1024), nullable=False)
    mime_type = sa.Column(sa.String(128), nullable=False)
    size_bytes = sa.Column(sa.BigInteger, nullable=False, default=0)
    created_at = sa.Column(sa.DateTime(timezone=True), default=_utcnow)

    job = relationship("OCRJob", back_populates="document", uselist=False)


class OCRJob(Base):
    __tablename__ = "ocr_jobs"

    id = sa.Column(sa.String(36), primary_key=True, default=_uuid)
    document_id = sa.Column(sa.String(36), sa.ForeignKey("documents.id", ondelete="SET NULL"), nullable=True)
    filename = sa.Column(sa.String(512), nullable=False)
    stored_filename = sa.Column(sa.String(512), nullable=False)
    mime_type = sa.Column(sa.String(128), nullable=False)
    file_size = sa.Column(sa.BigInteger, nullable=False, default=0)

    # pending -> processing -> completed | failed
    status = sa.Column(sa.String(32), nullable=False, default="pending", index=True)
    error = sa.Column(sa.Text, nullable=True)

    language = sa.Column(sa.String(16), nullable=True)
    engine = sa.Column(sa.String(64), nullable=True)
    engine_version = sa.Column(sa.String(64), nullable=True)
    device = sa.Column(sa.String(16), nullable=True)  # cpu | cuda
    confidence = sa.Column(sa.Float, nullable=True)
    page_count = sa.Column(sa.Integer, nullable=False, default=0)
    processing_time = sa.Column(sa.Float, nullable=True)
    tokens_processed = sa.Column(sa.Integer, nullable=True)  # output tokens (generative engines only)
    peak_memory_mb = sa.Column(sa.Float, nullable=True)
    cpu_percent = sa.Column(sa.Float, nullable=True)
    error_code = sa.Column(sa.String(48), nullable=True)
    # Filled only when ground truth exists (verified corrections / benchmarks)
    verified_cer = sa.Column(sa.Float, nullable=True)
    verified_wer = sa.Column(sa.Float, nullable=True)

    document_type = sa.Column(sa.String(64), nullable=True)
    document_type_confidence = sa.Column(sa.Float, nullable=True)

    text = sa.Column(sa.Text, nullable=True)
    structured_data = sa.Column(sa.JSON, nullable=True)
    options = sa.Column(sa.JSON, nullable=True)

    created_at = sa.Column(sa.DateTime(timezone=True), default=_utcnow, index=True)
    updated_at = sa.Column(sa.DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)

    document = relationship("Document", back_populates="job")
    pages = relationship(
        "OCRPage",
        back_populates="job",
        cascade="all, delete-orphan",
        order_by="OCRPage.page_number",
    )
    regions = relationship("OCRRegion", back_populates="job", cascade="all, delete-orphan")


class OCRPage(Base):
    __tablename__ = "ocr_pages"

    id = sa.Column(sa.String(36), primary_key=True, default=_uuid)
    job_id = sa.Column(sa.String(36), sa.ForeignKey("ocr_jobs.id", ondelete="CASCADE"), nullable=False, index=True)
    page_number = sa.Column(sa.Integer, nullable=False)
    text = sa.Column(sa.Text, nullable=True)
    confidence = sa.Column(sa.Float, nullable=True)
    width = sa.Column(sa.Integer, nullable=True)
    height = sa.Column(sa.Integer, nullable=True)
    image_path = sa.Column(sa.String(1024), nullable=True)

    job = relationship("OCRJob", back_populates="pages")
    blocks = relationship("OCRBlock", back_populates="page", cascade="all, delete-orphan")


class OCRBlock(Base):
    __tablename__ = "ocr_blocks"

    id = sa.Column(sa.String(36), primary_key=True, default=_uuid)
    page_id = sa.Column(sa.String(36), sa.ForeignKey("ocr_pages.id", ondelete="CASCADE"), nullable=False, index=True)
    text = sa.Column(sa.Text, nullable=False)
    confidence = sa.Column(sa.Float, nullable=True)
    bbox = sa.Column(sa.JSON, nullable=True)  # [x1, y1, x2, y2]
    language = sa.Column(sa.String(16), nullable=True)
    block_type = sa.Column(sa.String(32), nullable=False, default="text")  # text | table_cell | header ...
    region_label = sa.Column(sa.String(32), nullable=True, default=None)

    page = relationship("OCRPage", back_populates="blocks")


class OCRCorrection(Base):
    __tablename__ = "ocr_corrections"

    id = sa.Column(sa.String(36), primary_key=True, default=_uuid)
    job_id = sa.Column(sa.String(36), sa.ForeignKey("ocr_jobs.id", ondelete="CASCADE"), nullable=False, index=True)
    page_number = sa.Column(sa.Integer, nullable=False, default=1)
    original_text = sa.Column(sa.Text, nullable=False)
    corrected_text = sa.Column(sa.Text, nullable=False)
    confidence = sa.Column(sa.Float, nullable=True)
    language = sa.Column(sa.String(16), nullable=True)
    bbox = sa.Column(sa.JSON, nullable=True)
    created_at = sa.Column(sa.DateTime(timezone=True), default=_utcnow)


class OCRRegion(Base):
    __tablename__ = "ocr_regions"

    id = sa.Column(sa.String(36), primary_key=True, default=_uuid)
    job_id = sa.Column(sa.String(36), sa.ForeignKey("ocr_jobs.id", ondelete="CASCADE"), nullable=False, index=True)
    page_number = sa.Column(sa.Integer, nullable=False)
    label = sa.Column(sa.String(32), nullable=False)
    x = sa.Column(sa.Float, nullable=False)
    y = sa.Column(sa.Float, nullable=False)
    width = sa.Column(sa.Float, nullable=False)
    height = sa.Column(sa.Float, nullable=False)
    order = sa.Column(sa.Integer, nullable=False, default=0)

    job = relationship("OCRJob", back_populates="regions")


class Benchmark(Base):
    """OCR Lab run: one document, several engines, real measurements."""

    __tablename__ = "benchmarks"

    id = sa.Column(sa.String(36), primary_key=True, default=_uuid)
    filename = sa.Column(sa.String(512), nullable=False)
    stored_filename = sa.Column(sa.String(512), nullable=False)
    mime_type = sa.Column(sa.String(128), nullable=False)
    ground_truth = sa.Column(sa.Text, nullable=True)
    language = sa.Column(sa.String(16), nullable=True)
    engines = sa.Column(sa.JSON, nullable=False, default=list)
    status = sa.Column(sa.String(32), nullable=False, default="pending", index=True)
    results = sa.Column(sa.JSON, nullable=True)
    error = sa.Column(sa.Text, nullable=True)
    created_at = sa.Column(sa.DateTime(timezone=True), default=_utcnow, index=True)
    completed_at = sa.Column(sa.DateTime(timezone=True), nullable=True)


class APIKey(Base):
    __tablename__ = "api_keys"

    id = sa.Column(sa.String(36), primary_key=True, default=_uuid)
    name = sa.Column(sa.String(255), nullable=False, default="Default key")
    prefix = sa.Column(sa.String(24), nullable=False)  # first chars, for display
    key_hash = sa.Column(sa.String(64), nullable=False, unique=True, index=True)
    revoked = sa.Column(sa.Boolean, nullable=False, default=False)
    created_at = sa.Column(sa.DateTime(timezone=True), default=_utcnow)
    last_used_at = sa.Column(sa.DateTime(timezone=True), nullable=True)

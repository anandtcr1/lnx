from datetime import datetime
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, field_validator

from app.services.languages import get as _get_language
from app.services.languages import normalize as _normalize_language

# ---------- Shared ----------

EngineName = Literal["auto", "tesseract", "easyocr", "qari", "wevisdoc", "paddle"]
LanguageOption = str  # any code from app.services.languages (validated below)
QualityMode = Literal["fast", "balanced", "high"]
DevicePreference = Literal["auto", "cpu", "cuda"]
QARIMode = Literal["auto", "printed", "handwritten"]
QARIVersion = Literal["v0.2", "v0.3"]


class RegionSpec(BaseModel):
    """One user-selected OCR region (Selective OCR). Coordinates are 0-1 normalized."""

    page_number: int
    label: str = ""
    x: float  # 0-1 normalized
    y: float  # 0-1 normalized
    width: float  # 0-1 normalized
    height: float  # 0-1 normalized
    order: int = 0


class RegionOut(BaseModel):
    page_number: int
    label: str
    x: float
    y: float
    width: float
    height: float
    order: int = 0

    model_config = {"from_attributes": True}


class OCROptions(BaseModel):
    engine: Optional[EngineName] = None
    language: LanguageOption = "auto"
    document_type: Optional[str] = None  # hint, overrides classifier
    quality_mode: QualityMode = "balanced"
    prefer_quality: bool = False  # quality over speed → structured parser (WeVisDoc) for non-Arabic auto docs
    device_preference: DevicePreference = "auto"
    deskew: bool = True
    denoise: bool = True
    auto_rotate: bool = True
    enhance_contrast: bool = True
    detect_tables: bool = False
    structured_extraction: bool = True
    preserve_layout: bool = True
    preserve_diacritics: bool = True
    preserve_punctuation: bool = True
    handwriting_detection: bool = False  # handwritten content → prefer QARI v0.3
    qari_mode: QARIMode = "auto"  # auto | printed (v0.2) | handwritten (v0.3)
    qari_version: Optional[QARIVersion] = None  # explicit override (OCR Lab variant)
    ocr_mode: Literal["full", "area", "multi"] = "full"
    region_specs: Optional[list[RegionSpec]] = None

    @field_validator("language")
    @classmethod
    def _validate_language(cls, value: str) -> str:
        if not str(value).strip():
            return "auto"
        code = _normalize_language(value)
        if code == "auto":
            return "auto"
        if code is None or _get_language(code) is None:
            raise ValueError(f"unsupported language '{value}'")
        return code


# ---------- Regions ----------


class RegionOut(BaseModel):
    page_number: int
    label: str
    x: float
    y: float
    width: float
    height: float
    order: int = 0

    model_config = {"from_attributes": True}


# ---------- Blocks / pages / jobs ----------


class BlockOut(BaseModel):
    id: str
    text: str
    confidence: Optional[float] = None
    bbox: Optional[list[float]] = None  # [x1, y1, x2, y2]
    language: Optional[str] = None
    block_type: str = "text"
    region_label: Optional[str] = None

    model_config = {"from_attributes": True}


class PageOut(BaseModel):
    id: str
    page_number: int
    text: Optional[str] = None
    confidence: Optional[float] = None
    width: Optional[int] = None
    height: Optional[int] = None
    image_url: Optional[str] = None
    blocks: list[BlockOut] = []

    model_config = {"from_attributes": True}


class JobSummary(BaseModel):
    id: str
    filename: str
    mime_type: str
    file_size: int = 0
    status: str
    language: Optional[str] = None
    engine: Optional[str] = None
    engine_version: Optional[str] = None
    device: Optional[str] = None
    confidence: Optional[float] = None
    page_count: int = 0
    processing_time: Optional[float] = None
    tokens_processed: Optional[int] = None  # output tokens (generative engines only)
    document_type: Optional[str] = None
    error_code: Optional[str] = None
    verified_cer: Optional[float] = None
    verified_wer: Optional[float] = None
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class JobDetail(JobSummary):
    error: Optional[str] = None
    peak_memory_mb: Optional[float] = None
    cpu_percent: Optional[float] = None
    document_type_confidence: Optional[float] = None
    structured_data: Optional[dict[str, Any]] = None
    options: Optional[dict[str, Any]] = None
    text: Optional[str] = None
    updated_at: Optional[datetime] = None
    pages: list[PageOut] = []
    regions: list[RegionOut] = []


class JobList(BaseModel):
    items: list[JobSummary]
    total: int


class JobCreated(BaseModel):
    job_id: str
    status: str


class PageTextUpdate(BaseModel):
    page_number: int
    text: str


class JobUpdate(BaseModel):
    text: Optional[str] = None
    pages: Optional[list[PageTextUpdate]] = None


class ReprocessRequest(BaseModel):
    engine: Optional[EngineName] = None


# ---------- Corrections ----------


class CorrectionCreate(BaseModel):
    job_id: str
    page_number: int = 1
    original_text: str
    corrected_text: str
    confidence: Optional[float] = None
    language: Optional[str] = None
    bbox: Optional[list[float]] = None


class CorrectionOut(CorrectionCreate):
    id: str
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


# ---------- Stats ----------


class StatsOverview(BaseModel):
    documents_processed: int
    pages_processed: int
    average_confidence: Optional[float] = None  # OCR confidence — NOT accuracy; None = no engine reported scores
    verified_accuracy: Optional[float] = None  # 1 - mean CER where ground truth exists; None = not measured
    verified_samples: int = 0
    average_processing_time: float
    failed_jobs: int = 0
    total_corrections: int
    total_tokens_processed: int = 0  # output tokens across generative-engine jobs


class StatsCharts(BaseModel):
    requests_per_day: list[dict[str, Any]]
    confidence_per_day: list[dict[str, Any]]
    language_distribution: list[dict[str, Any]]
    file_types: list[dict[str, Any]]
    engine_usage: list[dict[str, Any]]


class EnginePerformance(BaseModel):
    engine: str
    jobs: int
    pages: int
    avg_processing_time: float
    avg_confidence: Optional[float] = None  # None = engine reported no confidence scores (e.g. QARI)
    avg_seconds_per_page: Optional[float] = None  # honest throughput: seconds / OCR'd page
    avg_tokens_per_sec: Optional[float] = None  # generative engines only; needs tokens_processed
    total_tokens: Optional[int] = None


class SystemInfo(BaseModel):
    cpu_cores: int
    cpu_host_cores: Optional[int] = None
    cpu_budget_cores: Optional[int] = None
    cpu_cgroup_quota_cores: Optional[float] = None
    gpu_available: bool
    gpu_name: Optional[str] = None
    platform: str
    python_version: str
    worker_mode: str
    default_engine: str
    omp_thread_limit: Optional[str] = None


# ---------- API keys ----------


class APIKeyCreate(BaseModel):
    name: str = Field(default="Default key", max_length=255)


class APIKeyCreated(BaseModel):
    id: str
    name: str
    key: str  # shown only once
    prefix: str
    created_at: datetime


class APIKeyOut(BaseModel):
    id: str
    name: str
    prefix: str
    revoked: bool
    created_at: Optional[datetime] = None
    last_used_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


# ---------- Users / Active Directory ----------


class UserOut(BaseModel):
    id: str
    username: Optional[str] = None
    display_name: Optional[str] = None
    email: Optional[str] = None
    is_admin: bool
    auth_source: Optional[str] = None
    is_active: bool = True
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}

    @field_validator("is_active", mode="before")
    @classmethod
    def _null_is_active(cls, v: Any) -> Any:
        return True if v is None else v  # rows created before the column existed


class DirectoryUserOut(BaseModel):
    username: str
    display_name: Optional[str] = None
    email: Optional[str] = None
    upn: Optional[str] = None
    department: Optional[str] = None
    title: Optional[str] = None
    registered: bool  # already added to the application


class UserCreate(BaseModel):
    username: str = Field(min_length=1, max_length=128)  # AD login name (sAMAccountName)
    is_admin: bool = False


class UserUpdate(BaseModel):
    """Change role and/or status. Users are never deleted: is_active=false disables them."""

    is_admin: Optional[bool] = None
    is_active: Optional[bool] = None


# ---------- Engines / system ----------


class EngineInfo(BaseModel):
    name: str
    available: bool
    languages: list[str]
    status: str = "UNAVAILABLE"  # READY | MODEL_NOT_INSTALLED | UNAVAILABLE | ERROR
    reason: Optional[str] = None
    model_path: Optional[str] = None
    version: Optional[str] = None
    device: str = "cpu"
    internet_required: bool = False
    model_source: str = "local"
    last_check: Optional[dict[str, Any]] = None
    details: Optional[dict[str, Any]] = None  # engine-specific (QARI versions, mode)


class LanguageInfo(BaseModel):
    code: str
    name_en: str
    name_ar: str
    script: str
    direction: str
    engines: dict[str, bool]


class OfflineStatus(BaseModel):
    offline_mode: bool
    network_access: bool
    network_guard_active: bool
    model_source: str
    auto_download_models: bool
    telemetry: bool
    models_dir: str
    models_dir_exists: bool


class SystemHealth(BaseModel):
    app_env: str
    version: str
    offline: OfflineStatus
    engines: list[EngineInfo]
    database: str
    queue: str
    disk_free_mb: float
    lab_enabled: bool
    swagger_enabled: bool


class SystemResources(BaseModel):
    cpu_percent: float
    cpu_cores: int
    cpu_host_cores: Optional[int] = None
    cpu_budget_cores: Optional[int] = None
    cpu_cgroup_quota_cores: Optional[float] = None
    memory: dict[str, Any]
    gpu: Optional[dict[str, Any]] = None
    worker_mode: str
    worker_count: int
    recommended_workers: int
    threads_per_worker: int
    queue_length: Optional[int] = None
    active_jobs: int
    pending_jobs: int
    completed_jobs: int
    failed_jobs: int
    avg_processing_time: Optional[float] = None
    p50_processing_time: Optional[float] = None
    p95_processing_time: Optional[float] = None


class StorageArea(BaseModel):
    name: str
    path: str
    bytes: int


class StorageReport(BaseModel):
    areas: list[StorageArea]
    disk_total_bytes: int
    disk_free_bytes: int


class CleanupRequest(BaseModel):
    targets: list[Literal["temp", "exports", "logs"]]


class CleanupResult(BaseModel):
    cleaned: list[str]
    freed_bytes: int


# ---------- Benchmarks (OCR Lab) ----------


class BenchmarkCreated(BaseModel):
    benchmark_id: str
    status: str


class BenchmarkOut(BaseModel):
    id: str
    filename: str
    mime_type: str
    ground_truth: Optional[str] = None
    language: Optional[str] = None
    engines: list[str]
    status: str
    results: Optional[list[dict[str, Any]]] = None
    error: Optional[str] = None
    created_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    model_config = {"from_attributes": True}

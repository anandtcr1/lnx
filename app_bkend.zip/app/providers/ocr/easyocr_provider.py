import asyncio
from typing import Any, Optional

from app.core.errors import ErrorCode, OCRError
from app.providers.base import (
    STATUS_MODEL_NOT_INSTALLED,
    STATUS_READY,
    STATUS_UNAVAILABLE,
    ModelStatus,
    OCRBlockResult,
    OCRProvider,
    OCRResult,
)
from app.services.hardware import gpu_available
from app.services.language_detect import detect_image_language, detect_script
from app.services.languages import DEFAULT_AUTO
from app.services.languages import AUTO, easyocr_langs, languages_for_engine, normalize
from app.services.model_repository import check_easyocr, engine_dir

_DECODER = {"fast": "greedy", "balanced": "greedy", "high": "beamsearch"}


class EasyOCRProvider(OCRProvider):
    """EasyOCR on pinned CPU-only PyTorch wheels; local weights only, downloads disabled."""

    name = "easyocr"
    languages = languages_for_engine("easyocr")

    def __init__(self) -> None:
        status = self.model_status()
        if status.status != STATUS_READY:
            raise OCRError(ErrorCode.MODEL_NOT_INSTALLED, detail=f"{status.reason} (expected in {status.model_path})")
        self._readers: dict[tuple, Any] = {}

    @classmethod
    def model_status(cls) -> ModelStatus:
        try:
            import easyocr  # noqa: F401
        except ImportError as exc:
            return ModelStatus(STATUS_UNAVAILABLE, reason=f"easyocr/torch not importable: {exc}")
        check = check_easyocr()
        if not check.ok:
            return ModelStatus(STATUS_MODEL_NOT_INSTALLED, reason=check.reason, model_path=check.path)
        return ModelStatus(
            STATUS_READY,
            model_path=check.path,
            version=cls.version(),
            device="cuda" if gpu_available() else "cpu",
        )

    @classmethod
    def version(cls) -> Optional[str]:
        try:
            import easyocr
            import torch

            return f"easyocr {getattr(easyocr, '__version__', '?')} / torch {torch.__version__}"
        except Exception:
            return None

    def device(self) -> str:
        return "cuda" if gpu_available() else "cpu"

    def _reader(self, language: str):
        langs = easyocr_langs(language)
        if langs is None:
            raise OCRError(
                ErrorCode.ENGINE_UNAVAILABLE,
                detail=f"EasyOCR does not support language '{language}'",
            )
        if langs not in self._readers:
            import easyocr

            model_dir = str(engine_dir("easyocr"))
            try:
                self._readers[langs] = easyocr.Reader(
                    list(langs),
                    gpu=gpu_available(),
                    model_storage_directory=model_dir,
                    user_network_directory=model_dir,
                    download_enabled=False,  # never fetch weights at runtime
                    verbose=False,
                )
            except FileNotFoundError as exc:
                raise OCRError(
                    ErrorCode.MODEL_NOT_INSTALLED,
                    detail=f"EasyOCR weights missing for {list(langs)}: {exc} (expected in {model_dir})",
                ) from exc
        return self._readers[langs]

    async def extract(self, file_path: str, options: dict[str, Any]) -> OCRResult:
        language = options.get("language") or AUTO
        if normalize(language) == AUTO:
            language = detect_image_language(file_path) or DEFAULT_AUTO
        decoder = _DECODER.get(options.get("quality_mode") or "balanced", "greedy")
        reader = self._reader(language)
        raw = await asyncio.to_thread(reader.readtext, file_path, decoder=decoder, paragraph=False)
        return self._parse(raw, language)

    @staticmethod
    def _parse(raw: Any, language: str) -> OCRResult:
        blocks: list[OCRBlockResult] = []
        for item in raw or []:
            try:
                box, text, score = item[0], item[1], float(item[2])
            except (TypeError, ValueError, IndexError):
                continue
            if not text or not str(text).strip():
                continue
            xs = [p[0] for p in box]
            ys = [p[1] for p in box]
            blocks.append(
                OCRBlockResult(
                    text=str(text).strip(),
                    confidence=score,
                    bbox=[float(min(xs)), float(min(ys)), float(max(xs)), float(max(ys))],
                    language=detect_script(str(text)),
                )
            )
        text = "\n".join(b.text for b in blocks)
        confidence = sum(b.confidence for b in blocks) / len(blocks) if blocks else 0.0
        return OCRResult(text=text, blocks=blocks, confidence=confidence, language=language)

"""QARI-OCR: offline Arabic OCR fine-tunes of Qwen2-VL-2B-Instruct (NAMAA-Space).

Two official model layouts, both loaded exclusively from local disk:

  v0.2  LoRA adapter  (NAMAA-Space/Qari-OCR-0.2.2.1-VL-2B-Instruct) loaded with
        PeftModel on a local Qwen2-VL-2B-Instruct base (QARI_BASE_MODEL_DIR).
  v0.3  Standalone fine-tune (NAMAA-Space/Qari-OCR-v0.3-VL-2B-Instruct) loaded
        directly with Qwen2VLForConditionalGeneration.

The provider never downloads anything: HF_HUB_OFFLINE / TRANSFORMERS_OFFLINE /
local_files_only are enforced here as well as by the process-wide network guard,
and model_status() reports MODEL_NOT_INSTALLED with the exact expected paths.

QARI generation does not emit a per-token OCR confidence score, so OCRResult
confidence is left as None (never an invented number). Each page becomes one
whole-page block with the reconstructed text.
"""

import asyncio
import os
from typing import Any, Optional

from app.core.config import settings
from app.core.errors import ErrorCode, OCRError
from app.providers.base import (
    STATUS_MODEL_NOT_INSTALLED,
    STATUS_READY,
    STATUS_UNAVAILABLE,
    ModelStatus,
    OCRBlockResult,
    OCRProvider,
    OCRResult,
)
from app.services import model_repository as mr
from app.services.hardware import gpu_available
from app.services.language_detect import detect_language, detect_script
from app.services.languages import languages_for_engine

# Official prompt from the NAMAA-Space model cards.
_QARI_PROMPT = (
    "Below is the image of one page of a document, as well as some raw textual "
    "content that was previously extracted for it. Just return the plain text "
    "representation of this document as if you were reading it naturally. "
    "Do not hallucinate."
)

_OFFLINE_ENV = {"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1"}


class QARIOCRProvider(OCRProvider):
    """QARI-OCR (Qwen2-VL-2B Arabic fine-tunes). Local weights only, offline by design."""

    name = "qari"
    languages = languages_for_engine("qari")

    def __init__(self) -> None:
        status = self.model_status()
        if status.status != STATUS_READY:
            raise OCRError(ErrorCode.MODEL_NOT_INSTALLED, detail=f"{status.reason} (expected in {status.model_path})")
        self._models: dict[str, tuple[Any, Any]] = {}  # version -> (model, processor)

    # ------------------------------------------------------------ status

    @classmethod
    def model_status(cls) -> ModelStatus:
        if not settings.QARI_ENABLED:
            return ModelStatus(STATUS_UNAVAILABLE, reason="QARI is disabled by QARI_ENABLED=false")
        for pkg in ("transformers", "qwen_vl_utils"):
            try:
                __import__(pkg)
            except ImportError as exc:
                return ModelStatus(STATUS_UNAVAILABLE, reason=f"{pkg} is not installed: {exc}")

        ready = mr.qari_ready_versions()
        if not ready:
            return ModelStatus(
                STATUS_MODEL_NOT_INSTALLED,
                reason=f"No QARI model files found under {mr.qari_dir()} — install v0.2 (LoRA) and/or v0.3 (standalone) offline, see models/README.md",
                model_path=str(mr.qari_dir()),
            )
        return ModelStatus(
            STATUS_READY,
            reason=", ".join(f"v{v} ready" for v in ready),
            model_path=str(mr.qari_dir()),
            version=cls.version(ready),
            device="cuda" if gpu_available() else "cpu",
            model_source="local",
            details={"versions": ready, "mode": "auto|printed|handwritten"},
        )

    @staticmethod
    def version(ready: Optional[list[str]] = None) -> Optional[str]:
        versions = ready or mr.qari_ready_versions() or []
        bits = " + ".join(versions) if versions else "v0.2/v0.3"
        return f"QARI-OCR {bits} (Qwen2-VL-2B-Instruct)"

    def device(self) -> str:
        return "cuda" if gpu_available() else "cpu"

    @classmethod
    def details(cls) -> Optional[dict]:
        return {"versions": mr.qari_ready_versions(), "mode": "auto|printed|handwritten"}

    # ------------------------------------------------------------ version selection

    def _pick_version(self, options: dict[str, Any]) -> tuple[str, list[str]]:
        ready = mr.qari_ready_versions()
        if not ready:
            raise OCRError(
                ErrorCode.MODEL_NOT_INSTALLED,
                detail=f"QARI models are not installed (expected under {mr.qari_dir()}). See models/README.md",
            )
        explicit = (options.get("qari_version") or "").strip().lower()
        if explicit in mr.QARI_VERSIONS:
            chosen = explicit
        else:
            mode = (options.get("qari_mode") or "auto").strip().lower()
            if mode == "printed":
                chosen = "v0.2"
            elif mode == "handwritten":
                chosen = "v0.3"
            else:  # auto
                chosen = "v0.3" if options.get("handwriting_detection") else settings.qari_default_version
        warnings: list[str] = []
        if chosen not in ready:
            fallback = ready[0] if ready else None
            if fallback is None:
                raise OCRError(ErrorCode.MODEL_NOT_INSTALLED, detail=f"QARI v{chosen} requested but not installed")
            warnings.append(f"QARI v{chosen} is not installed locally — using local v{fallback} instead.")
            chosen = fallback
        return chosen, warnings

    # ------------------------------------------------------------ heavy resources

    def _load(self, version: str) -> tuple[Any, Any]:
        if version in self._models:
            return self._models[version]
        import torch
        from transformers import AutoProcessor

        for key, value in _OFFLINE_ENV.items():
            os.environ.setdefault(key, value)

        use_cuda = gpu_available()
        torch_dtype = torch.float16 if use_cuda else torch.bfloat16

        directory = mr.qari_dir(version)
        if mr._is_lora_adapter(directory):
            from peft import PeftModel
            from transformers import Qwen2VLForConditionalGeneration

            base_dir = mr.qari_base_dir()
            try:
                base = Qwen2VLForConditionalGeneration.from_pretrained(
                    str(base_dir), torch_dtype=torch_dtype, local_files_only=True
                )
                model = PeftModel.from_pretrained(base, str(directory), torch_dtype=torch_dtype, local_files_only=True)
            except Exception as exc:
                raise OCRError(
                    ErrorCode.MODEL_NOT_INSTALLED,
                    detail=f"QARI v{version} LoRA adapter could not load base from {base_dir}: {type(exc).__name__}: {str(exc)[:200]}",
                ) from exc
            processor = AutoProcessor.from_pretrained(str(directory), local_files_only=True)
        else:
            from transformers import Qwen2VLForConditionalGeneration

            try:
                model = Qwen2VLForConditionalGeneration.from_pretrained(
                    str(directory), torch_dtype=torch_dtype, local_files_only=True
                )
            except Exception as exc:
                raise OCRError(
                    ErrorCode.MODEL_NOT_INSTALLED,
                    detail=f"QARI v{version} standalone checkpoint could not load from {directory}: {type(exc).__name__}: {str(exc)[:200]}",
                ) from exc
            processor = AutoProcessor.from_pretrained(str(directory), local_files_only=True)

        device = "cuda" if use_cuda else "cpu"
        model.to(device)
        model.eval()
        self._models[version] = (model, processor)
        return model, processor

    # ------------------------------------------------------------ OCR

    async def extract(self, file_path: str, options: dict[str, Any]) -> OCRResult:
        version, extra_warnings = self._pick_version(options)
        model, processor = self._load(version)
        max_new_tokens = max(16, int(options.get("max_new_tokens") or settings.QARI_MAX_TOKENS))
        return await asyncio.to_thread(
            self._run_generation, model, processor, file_path, max_new_tokens, extra_warnings
        )

    def _run_generation(
        self, model: Any, processor: Any, file_path: str, max_new_tokens: int, extra_warnings: list[str]
    ) -> OCRResult:
        import torch
        from PIL import Image
        from qwen_vl_utils import process_vision_info

        from app.services.hardware import configure_inference_threads, heavy_inference_guard

        configure_inference_threads()
        image = Image.open(file_path).convert("RGB")
        width, height = image.size
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": str(file_path)},
                    {"type": "text", "text": _QARI_PROMPT},
                ],
            }
        ]
        image_inputs, _video_inputs = process_vision_info(messages)
        text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = processor(text=[text], images=image_inputs, return_tensors="pt")
        device = next(model.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}

        with heavy_inference_guard():
            with torch.inference_mode():
                outputs = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False, min_length=1)
        output_ids = outputs[:, inputs["input_ids"].shape[1]:]
        extracted = processor.batch_decode(output_ids, skip_special_tokens=True)[0].strip()

        warnings = list(extra_warnings)
        if not extracted:
            warnings.append("QARI returned empty text for this page.")
        if extracted.split():
            detected = detect_language(extracted) or "ar"
        else:
            detected = None

        block = OCRBlockResult(
            text=extracted,
            confidence=None,  # QARI has no native confidence score — never invented
            bbox=[0.0, 0.0, float(width), float(height)],
            language=detect_script(extracted) if extracted else None,
        )
        return OCRResult(
            text=extracted,
            blocks=[block] if extracted else [],
            confidence=None,
            language=detected,
            warnings=warnings,
            tokens_in=int(inputs["input_ids"].shape[1]),
            tokens_out=int(output_ids.shape[1]),
        )

    # ------------------------------------------------------------ health probe

    def health_check(self) -> dict:
        """Real local inference probe with a small token budget so it stays bounded."""
        import tempfile
        import time

        from PIL import Image, ImageDraw

        started = time.perf_counter()
        tmp_dir = tempfile.mkdtemp(prefix="ocr-health-qari-")
        path = os.path.join(tmp_dir, "probe.png")
        try:
            img = Image.new("RGB", (320, 90), "white")
            ImageDraw.Draw(img).text((12, 30), "OCR 123 test", fill="black")
            img.save(path)
            result = asyncio.run(self.extract(path, {"language": "en", "quality_mode": "fast", "max_new_tokens": 64}))
            return {
                "status": "PASS" if result.text else "FAIL",
                "time": round(time.perf_counter() - started, 3),
                "text_sample": (result.text or "")[:60] or None,
                "error": None if result.text else "QARI produced no text on the health probe",
            }
        except Exception as exc:  # noqa: BLE001 — report, don't crash
            return {
                "status": "FAIL",
                "time": round(time.perf_counter() - started, 3),
                "text_sample": None,
                "error": f"{type(exc).__name__}: {str(exc)[:200]}",
            }
        finally:
            try:
                os.remove(path)
                os.rmdir(tmp_dir)
            except OSError:
                pass
import asyncio
import shutil
from typing import Any, Optional

from app.providers.base import (
    STATUS_MODEL_NOT_INSTALLED,
    STATUS_READY,
    STATUS_UNAVAILABLE,
    ModelStatus,
    OCRBlockResult,
    OCRProvider,
    OCRResult,
)
from app.services.language_detect import detect_image_language, detect_script
from app.services.languages import DEFAULT_AUTO
from app.services.languages import AUTO, languages_for_engine, normalize, tesseract_code
from app.services.model_repository import check_tesseract, tessdata_dir

# quality_mode → (tessdata set, OCR engine mode)
_QUALITY = {
    "fast": ("speed", 1),
    "balanced": (None, 1),  # None = follow TESSERACT_MODE setting
    "high": ("accuracy", 1),
}


class TesseractOCRProvider(OCRProvider):
    """Lightweight CPU engine; the broad-coverage local fallback."""

    name = "tesseract"
    languages = languages_for_engine("tesseract")

    @classmethod
    def model_status(cls) -> ModelStatus:
        try:
            import pytesseract  # noqa: F401
        except ImportError:
            return ModelStatus(STATUS_UNAVAILABLE, reason="pytesseract is not installed")
        if shutil.which("tesseract") is None:
            return ModelStatus(STATUS_UNAVAILABLE, reason="tesseract binary not found on PATH")
        check = check_tesseract()
        if not check.ok:
            return ModelStatus(STATUS_MODEL_NOT_INSTALLED, reason=check.reason, model_path=check.path)
        return ModelStatus(STATUS_READY, model_path=check.path, version=cls.version())

    @classmethod
    def version(cls) -> Optional[str]:
        try:
            import pytesseract

            return str(pytesseract.get_tesseract_version())
        except Exception:
            return None

    async def extract(self, file_path: str, options: dict[str, Any]) -> OCRResult:
        language = options.get("language") or AUTO
        if normalize(language) == AUTO:
            language = detect_image_language(file_path) or DEFAULT_AUTO
        lang_code = tesseract_code(language, "eng")
        mode, oem = _QUALITY.get(options.get("quality_mode") or "balanced", (None, 1))
        return await asyncio.to_thread(self._run, file_path, lang_code, language, mode, oem)

    def _run(self, file_path: str, lang_code: str, language: str, mode: Optional[str], oem: int) -> OCRResult:
        import pytesseract
        from pytesseract import Output

        config = f'--tessdata-dir "{tessdata_dir(mode)}" --oem {oem}'
        data = pytesseract.image_to_data(file_path, lang=lang_code, config=config, output_type=Output.DICT)

        lines: dict[tuple, dict[str, Any]] = {}
        for i in range(len(data.get("text", []))):
            word = (data["text"][i] or "").strip()
            try:
                conf = float(data["conf"][i])
            except (TypeError, ValueError):
                conf = -1.0
            if not word or conf < 0:
                continue
            key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
            left, top = data["left"][i], data["top"][i]
            right, bottom = left + data["width"][i], top + data["height"][i]
            entry = lines.setdefault(key, {"words": [], "confs": [], "box": [left, top, right, bottom]})
            entry["words"].append(word)
            entry["confs"].append(conf)
            box = entry["box"]
            box[0], box[1] = min(box[0], left), min(box[1], top)
            box[2], box[3] = max(box[2], right), max(box[3], bottom)

        blocks: list[OCRBlockResult] = []
        for entry in lines.values():
            text = " ".join(entry["words"]).strip()
            if not text:
                continue
            blocks.append(
                OCRBlockResult(
                    text=text,
                    confidence=round(sum(entry["confs"]) / len(entry["confs"]) / 100.0, 4),
                    bbox=[float(v) for v in entry["box"]],
                    language=detect_script(text),
                )
            )

        blocks.sort(key=lambda b: (b.bbox[1], b.bbox[0]))
        text = "\n".join(b.text for b in blocks)
        confidence = sum(b.confidence for b in blocks) / len(blocks) if blocks else 0.0
        return OCRResult(text=text, blocks=blocks, confidence=confidence, language=language)

"""Export OCR results and corrections to TXT / JSON / CSV / JSONL."""

import csv
import io
import json
from typing import Any

from app.models.models import OCRCorrection, OCRJob


def job_to_txt(job: OCRJob) -> str:
    parts = []
    for page in job.pages:
        if job.page_count > 1:
            parts.append(f"--- Page {page.page_number} ---")
        parts.append(page.text or "")
        parts.append("")
    return "\n".join(parts).strip() + "\n"


def job_to_dict(job: OCRJob) -> dict[str, Any]:
    return {
        "job_id": job.id,
        "filename": job.filename,
        "status": job.status,
        "language": job.language,
        "engine": job.engine,
        "confidence": job.confidence,
        "document_type": job.document_type,
        "document_type_confidence": job.document_type_confidence,
        "page_count": job.page_count,
        "processing_time": job.processing_time,
        "structured_data": job.structured_data,
        "text": job.text,
        "pages": [
            {
                "page_number": p.page_number,
                "text": p.text,
                "confidence": p.confidence,
                "width": p.width,
                "height": p.height,
                "blocks": [
                    {
                        "text": b.text,
                        "confidence": b.confidence,
                        "bbox": b.bbox,
                        "language": b.language,
                        "block_type": b.block_type,
                    }
                    for b in p.blocks
                ],
            }
            for p in job.pages
        ],
    }


def job_to_json(job: OCRJob) -> str:
    return json.dumps(job_to_dict(job), ensure_ascii=False, indent=2)


def job_to_csv(job: OCRJob) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["page", "block_text", "confidence", "x1", "y1", "x2", "y2", "language", "block_type"])
    for page in job.pages:
        for b in page.blocks:
            bbox = b.bbox or [None, None, None, None]
            writer.writerow([page.page_number, b.text, b.confidence, *bbox, b.language, b.block_type])
    return buf.getvalue()


def corrections_to_json(rows: list[OCRCorrection]) -> str:
    return json.dumps([correction_to_dict(r) for r in rows], ensure_ascii=False, indent=2)


def corrections_to_jsonl(rows: list[OCRCorrection]) -> str:
    return "\n".join(json.dumps(correction_to_dict(r), ensure_ascii=False) for r in rows) + "\n"


def corrections_to_csv(rows: list[OCRCorrection]) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(
        ["id", "job_id", "page_number", "original_text", "corrected_text", "confidence", "language", "bbox", "created_at"]
    )
    for r in rows:
        writer.writerow(
            [
                r.id, r.job_id, r.page_number, r.original_text, r.corrected_text,
                r.confidence, r.language, json.dumps(r.bbox or []), r.created_at.isoformat() if r.created_at else "",
            ]
        )
    return buf.getvalue()


def correction_to_dict(r: OCRCorrection) -> dict[str, Any]:
    return {
        "id": r.id,
        "job_id": r.job_id,
        "page_number": r.page_number,
        "original_text": r.original_text,
        "corrected_text": r.corrected_text,
        "confidence": r.confidence,
        "language": r.language,
        "bbox": r.bbox,
        "created_at": r.created_at.isoformat() if r.created_at else None,
    }

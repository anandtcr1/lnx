"""Keyword-scored document classification (Arabic + English).

A transparent heuristic classifier — no fake ML. Each category has weighted
keywords; the best-scoring category wins with a normalized confidence.
"""

from typing import Optional

CATEGORIES: dict[str, dict[str, float]] = {
    "invoice": {
        "invoice": 3, "فاتورة": 3, "invoice number": 3, "رقم الفاتورة": 3,
        "vat": 2, "الضريبة": 2, "الرقم الضريبي": 3, "tax": 2,
        "total": 1.5, "الإجمالي": 2, "المجموع": 1.5, "subtotal": 1.5,
        "bill to": 2, "due date": 2, "amount due": 2, "حالة السداد": 1.5,
    },
    "receipt": {
        "receipt": 3, "إيصال": 3, "سند قبض": 3, "سند صرف": 3,
        "cash": 1.5, "نقداً": 1.5, "paid": 1.5, "المدفوع": 2,
        "thank you": 1, "change": 1, "الباقي": 1,
    },
    "id_document": {
        "identity": 3, "الهوية": 3, "بطاقة": 2, "id card": 3,
        "passport": 3, "جواز": 3, "رخصة": 2, "license": 2, "licence": 2,
        "date of birth": 2, "تاريخ الميلاد": 2, "الجنسية": 2, "nationality": 2,
        "expiry": 1.5, "تاريخ الانتهاء": 1.5, "رقم الهوية": 3, "national id": 3,
        "الإقامة": 2, "residence": 1.5,
    },
    "government_document": {
        "ministry": 3, "وزارة": 3, "المملكة": 2, "kingdom": 2,
        "الإدارة العامة": 2, "government": 2, "حكومة": 2, "حكومي": 2,
        "royal": 1.5, "ديوان": 2, "الأمر الملكي": 3, "emirate": 1.5, "إمارة": 1.5,
        "المحافظة": 1.5, "governorate": 1.5, "البلدية": 1.5, "municipality": 1.5,
        "official": 1, "رسمي": 1,
    },
    "letter": {
        "dear": 2, "السيد": 1.5, "المحترم": 1.5, "تحية طيبة": 3,
        "وبعد": 2, "yours sincerely": 2, "مع خالص التحية": 2, "وتقبلوا": 2,
        "subject": 1.5, "الموضوع": 2, "reference": 1.5, "الإشارة": 1.5,
        "نسخة من": 1, "cc": 1,
    },
    "contract": {
        "contract": 3, "عقد": 3, "agreement": 3, "اتفاقية": 3,
        "party": 2, "الطرف الأول": 3, "الطرف الثاني": 3, "first party": 3, "second party": 3,
        "terms and conditions": 2, "الشروط والأحكام": 2, "clause": 1.5, "مادة": 1,
        "signature": 1.5, "التوقيع": 1.5, "witness": 1.5, "الشهود": 1.5,
    },
    "certificate": {
        "certificate": 3, "شهادة": 3, "certify": 2, "يشهد": 2, "نشهد": 2,
        "awarded": 1.5, "منحت": 1.5, "completion": 1.5, "إتمام": 1.5,
        "graduation": 2, "التخرج": 2, "diploma": 2, "بكالوريوس": 2, "degree": 1.5,
    },
    "report": {
        "report": 3, "تقرير": 3, "executive summary": 2, "الملخص التنفيذي": 2,
        "introduction": 1.5, "مقدمة": 1.5, "conclusion": 1.5, "الخاتمة": 1.5,
        "findings": 1.5, "النتائج": 1.5, "recommendations": 1.5, "التوصيات": 1.5,
        "analysis": 1.5, "تحليل": 1.5, "methodology": 1.5,
    },
    "form": {
        "form": 3, "نموذج": 3, "application form": 3, "طلب": 1.5,
        "please fill": 2, "يرجى تعبئة": 2, "signature of applicant": 2, "توقيع مقدم الطلب": 2,
        "checkbox": 1, "gender": 1.5, "الجنس": 1.5, "marital status": 1.5, "الحالة الاجتماعية": 1.5,
    },
    "screenshot": {
        "http://": 1.5, "https://": 1.5, "www.": 1.5,
        "reply": 1, "share": 1, "comment": 1, "like": 1, "مشاركة": 1, "تعليق": 1,
        "followers": 1.5, "متابعون": 1.5, "subscribe": 1.5, "login": 1, "تسجيل الدخول": 1.5,
        "search": 0.5, "بحث": 0.5,
    },
}


def classify_document(text: str, mime_type: str = "", page_count: int = 1) -> tuple[str, float]:
    """Return (document_type, confidence 0..1)."""
    haystack = (text or "").lower()
    if not haystack.strip():
        return "other", 0.5

    scores: dict[str, float] = {}
    for category, keywords in CATEGORIES.items():
        score = 0.0
        for keyword, weight in keywords.items():
            occurrences = haystack.count(keyword.lower())
            if occurrences:
                score += weight * min(occurrences, 3)
        if score > 0:
            scores[category] = score

    if not scores:
        # Screenshots are usually single-page images with little keyword signal.
        if page_count == 1 and mime_type.startswith("image/"):
            return "screenshot", 0.55
        return "other", 0.5

    best = max(scores, key=scores.get)
    total = sum(scores.values())
    confidence = 0.5 + 0.49 * (scores[best] / total) if total else 0.5
    return best, round(min(confidence, 0.99), 3)


def list_document_types() -> list[str]:
    return sorted(list(CATEGORIES.keys()) + ["other"])

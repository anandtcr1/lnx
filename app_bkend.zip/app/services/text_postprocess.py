"""Text reconstruction from positioned blocks + user-selected preservation options."""

import re

from app.providers.base import OCRBlockResult
from app.services.language_detect import detect_script
from app.services.metrics import strip_diacritics

_PUNCT = re.compile(r"[^\w\s\u0600-\u06FF]", re.UNICODE)


def reconstruct(blocks: list[OCRBlockResult], *, preserve_layout: bool = True) -> str:
    """Group blocks into visual lines (top→bottom), order within a line by reading direction."""
    if not blocks:
        return ""
    items = sorted(blocks, key=lambda b: ((b.bbox[1] + b.bbox[3]) / 2, b.bbox[0]))
    lines: list[list[OCRBlockResult]] = []
    for block in items:
        cy = (block.bbox[1] + block.bbox[3]) / 2
        h = max(block.bbox[3] - block.bbox[1], 1)
        if lines:
            last = lines[-1]
            last_cy = sum((b.bbox[1] + b.bbox[3]) / 2 for b in last) / len(last)
            if abs(cy - last_cy) <= 0.6 * h:
                last.append(block)
                continue
        lines.append([block])

    rendered: list[str] = []
    prev_bottom: float | None = None
    for line in lines:
        rtl = detect_script(" ".join(b.text for b in line)) in ("ar", "mixed")
        line.sort(key=lambda b: b.bbox[0], reverse=rtl)
        text = " ".join(b.text for b in line)
        top = min(b.bbox[1] for b in line)
        bottom = max(b.bbox[3] for b in line)
        if preserve_layout and prev_bottom is not None and top - prev_bottom > 1.5 * (bottom - top):
            rendered.append("")  # paragraph gap
        rendered.append(text)
        prev_bottom = bottom

    return "\n".join(rendered) if preserve_layout else " ".join(t for t in rendered if t)


def apply_preservation(text: str, *, preserve_diacritics: bool = True, preserve_punctuation: bool = True) -> str:
    if not preserve_diacritics:
        text = strip_diacritics(text)
    if not preserve_punctuation:
        text = _PUNCT.sub("", text)
        text = re.sub(r"[ \t]{2,}", " ", text)
    return text

"""Resource awareness: safe worker sizing + live system/queue metrics.

Worker counts are never hardcoded — they derive from cores, RAM and the
per-worker footprint of the OCR engines, unless an operator pins a number.
"""

import os
import shutil
import subprocess
from typing import Optional

import psutil
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.models import OCRJob
from app.services.hardware import cpu_budget_details, cpu_cores, gpu_available, gpu_name

# Target threads per worker when the value is "auto". Keeps each engine near the
# thread count where PyTorch/OpenCV CPU scaling plateaus, while ensuring the
# aggregate (workers × threads) never exceeds the real CPU budget.
_AUTO_THREADS_PER_WORKER = 4


def _pinned_threads() -> Optional[int]:
    raw = str(settings.OCR_THREADS_PER_WORKER or "auto").strip().lower()
    if raw.isdigit() and int(raw) > 0:
        return int(raw)
    return None


def memory_info() -> dict:
    vm = psutil.virtual_memory()
    return {
        "total": vm.total,
        "available": vm.available,
        "used": vm.used,
        "percent": vm.percent,
    }


def recommended_workers() -> int:
    """min(cores / threads_per_worker, RAM / RAM_per_worker), at least 1.

    `cores` is the effective budget (host ∩ cgroup quota ∩ affinity), so a
    container limited to 2 CPUs never spawns 8 workers.
    """
    cores = cpu_cores()
    threads = _pinned_threads() or _AUTO_THREADS_PER_WORKER
    ram_gb = psutil.virtual_memory().total / 2**30
    by_cpu = max(1, cores // threads)
    by_ram = max(1, int(ram_gb // max(0.5, settings.OCR_RAM_PER_WORKER_GB)))
    return max(1, min(by_cpu, by_ram, cores))


def effective_workers() -> int:
    raw = (settings.OCR_WORKER_CONCURRENCY or "auto").strip().lower()
    if raw.isdigit() and int(raw) > 0:
        return int(raw)
    return recommended_workers()


def threads_per_worker() -> int:
    """Threads each worker may use.

    Pinned value wins; otherwise the CPU budget is divided evenly across the
    workers so workers × threads ≈ budget: no oversubscription (throttling) and
    no idle cores.
    """
    pinned = _pinned_threads()
    if pinned:
        return pinned
    return max(1, cpu_cores() // max(1, effective_workers()))


def apply_thread_budget(threads: Optional[int] = None) -> int:
    """Cap BLAS/OpenMP/PyTorch/OpenCV threads for THIS process.

    Operator-provided env vars win (setdefault); everything else is derived so
    a worker never uses more threads than its share of the CPU budget.
    """
    value = max(1, threads or threads_per_worker())
    for var in (
        "OMP_NUM_THREADS",
        "MKL_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "OMP_THREAD_LIMIT",
    ):
        os.environ.setdefault(var, str(value))
    try:
        import cv2

        cv2.setNumThreads(value)
    except Exception:
        pass
    try:
        import torch

        torch.set_num_threads(value)
    except Exception:
        pass
    return value


def gpu_stats() -> Optional[dict]:
    if shutil.which("nvidia-smi") is None:
        return None
    try:
        out = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=utilization.gpu,memory.used,memory.total",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=5,
        ).stdout.strip().splitlines()
        if not out:
            return None
        util, used, total = [float(x.strip()) for x in out[0].split(",")[:3]]
        return {
            "available": gpu_available(),
            "name": gpu_name(),
            "utilization_percent": util,
            "vram_used_mb": used,
            "vram_total_mb": total,
        }
    except Exception:
        return None


def queue_length() -> Optional[int]:
    if settings.WORKER_MODE != "celery":
        return None
    try:
        import redis

        client = redis.Redis.from_url(settings.REDIS_URL, socket_connect_timeout=1)
        return int(client.llen("celery"))
    except Exception:
        return None


def job_counts(db: Session) -> dict:
    rows = db.query(OCRJob.status, func.count(OCRJob.id)).group_by(OCRJob.status).all()
    counts = {status: int(c) for status, c in rows}
    return {
        "pending": counts.get("pending", 0),
        "processing": counts.get("processing", 0),
        "completed": counts.get("completed", 0),
        "failed": counts.get("failed", 0),
    }


def _percentile(values: list[float], q: float) -> Optional[float]:
    if not values:
        return None
    ordered = sorted(values)
    idx = int(round((len(ordered) - 1) * q))
    return round(ordered[idx], 3)


def processing_percentiles(db: Session) -> dict:
    values = [
        float(v)
        for (v,) in db.query(OCRJob.processing_time)
        .filter(OCRJob.status == "completed", OCRJob.processing_time.isnot(None))
        .order_by(OCRJob.created_at.desc())
        .limit(5000)
        .all()
    ]
    avg = round(sum(values) / len(values), 3) if values else None
    return {"avg": avg, "p50": _percentile(values, 0.5), "p95": _percentile(values, 0.95), "samples": len(values)}


def snapshot(db: Session) -> dict:
    counts = job_counts(db)
    perf = processing_percentiles(db)
    budget = cpu_budget_details()
    return {
        "cpu_percent": psutil.cpu_percent(interval=0.2),
        "cpu_cores": cpu_cores(),
        "cpu_host_cores": budget["host_cores"],
        "cpu_budget_cores": budget["effective_cores"],
        "cpu_cgroup_quota_cores": budget["cgroup_quota_cores"],
        "memory": memory_info(),
        "gpu": gpu_stats(),
        "worker_mode": settings.WORKER_MODE,
        "worker_count": effective_workers(),
        "recommended_workers": recommended_workers(),
        "threads_per_worker": threads_per_worker(),
        "queue_length": queue_length(),
        "active_jobs": counts["processing"],
        "pending_jobs": counts["pending"],
        "completed_jobs": counts["completed"],
        "failed_jobs": counts["failed"],
        "avg_processing_time": perf["avg"],
        "p50_processing_time": perf["p50"],
        "p95_processing_time": perf["p95"],
    }

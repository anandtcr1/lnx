"""The OCR processing pipeline (offline, local models only).

Upload → validate → disk check → render/preprocess pages → OCR with engine
failover → bounding boxes + confidence → text reconstruction → language →
classification → structured extraction → tables → database → local job log.
Runs inside a Celery worker or an inline thread.
"""

import asyncio
import os
import shutil
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import SessionLocal
from app.core.errors import ErrorCode, OCRError, classify_exception
from app.core.logging_config import job_logger
from app.models.models import Document, OCRBlock, OCRJob, OCRPage, OCRRegion
from app.providers.ocr import resolve_providers_ordered
from app.services import preprocessing, table_extraction
from app.services.classify import classify_document
from app.services.language_detect import detect_language
from app.services.languages import AUTO, normalize
from app.services.model_repository import disk_free_mb
from app.services.resource_monitor import ResourceSampler
from app.services.structured_extraction import extract_structured_fields
from app.services.text_postprocess import apply_preservation, reconstruct
from app.storage import get_storage

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp", ".pdf"}
ALLOWED_MIMES = {
    "application/pdf",
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/tiff",
    "image/bmp",
    "image/x-tiff",
}


# ---------------------------------------------------------------- upload / job records


def save_upload(filename: str, data: bytes, mime_type: str) -> tuple[str, str]:
    """Validate + persist an upload under a random UUID name. Returns (stored_filename, key)."""
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise OCRError(
            ErrorCode.UNSUPPORTED_FILE,
            detail=f"'{ext}' not in {', '.join(sorted(ALLOWED_EXTENSIONS))}",
        )
    if mime_type and mime_type not in ALLOWED_MIMES and not mime_type.startswith("image/"):
        raise OCRError(ErrorCode.UNSUPPORTED_FILE, detail=f"MIME type '{mime_type}'")
    if len(data) > settings.max_upload_bytes:
        raise OCRError(ErrorCode.UNSUPPORTED_FILE, detail=f"file exceeds {settings.MAX_UPLOAD_SIZE_MB} MB")
    try:
        preprocessing.validate_upload(filename, mime_type, data[:16])
    except ValueError as exc:
        raise OCRError(ErrorCode.UNSUPPORTED_FILE, detail=str(exc)) from exc

    stored_filename = f"{uuid.uuid4().hex}{ext}"
    key = f"uploads/{stored_filename}"
    get_storage().save(key, data)
    return stored_filename, key


def create_job(db: Session, filename: str, mime_type: str, stored_filename: str, options: dict[str, Any]) -> OCRJob:
    storage = get_storage()
    stored_path = storage.path_for(f"uploads/{stored_filename}")

    document = Document(
        filename=filename,
        stored_path=stored_path,
        mime_type=mime_type,
        size_bytes=_file_size(stored_path),
    )
    db.add(document)
    db.flush()

    job = OCRJob(
        document_id=document.id,
        filename=filename,
        stored_filename=stored_filename,
        mime_type=mime_type,
        file_size=document.size_bytes,
        status="pending",
        options=options,
    )
    db.add(job)
    db.commit()
    db.refresh(job)
    return job


def enqueue_processing(job_id: str) -> None:
    """Dispatch to Celery when configured, otherwise process in a daemon thread."""
    if settings.WORKER_MODE == "celery":
        from app.workers.tasks import process_ocr_job_task

        process_ocr_job_task.delay(job_id)
    else:
        import threading

        threading.Thread(target=process_job, args=(job_id,), daemon=True).start()


def reset_for_reprocess(db: Session, job: OCRJob, engine: Optional[str]) -> None:
    for page in list(job.pages):
        db.delete(page)
    for region in list(job.regions):
        db.delete(region)
    job.status = "pending"
    job.error = None
    job.error_code = None
    job.text = None
    job.confidence = None
    job.language = None
    job.page_count = 0
    job.processing_time = None
    job.peak_memory_mb = None
    job.cpu_percent = None
    job.tokens_processed = None
    job.device = None
    job.engine_version = None
    job.document_type = None
    job.document_type_confidence = None
    job.structured_data = None
    options = dict(job.options or {})
    if engine:
        options["engine"] = engine
    job.options = options
    db.commit()


# ---------------------------------------------------------------- worker entry


def process_job(job_id: str) -> None:
    """Worker entry point: full pipeline for one job. Owns its DB session."""
    db = SessionLocal()
    job = db.get(OCRJob, job_id)
    if job is None:
        db.close()
        return

    started_at = datetime.now(timezone.utc)
    started = time.perf_counter()
    job.status = "processing"
    job.error = None
    job.error_code = None
    db.commit()

    sampler = ResourceSampler()
    try:
        with sampler:
            _run_pipeline(db, job)
        job.status = "completed"
    except BaseException as exc:  # noqa: BLE001 — every failure becomes a coded job error
        err = classify_exception(exc)
        job.status = "failed"
        job.error_code = err.code.value
        job.error = err.public_message(settings.is_development)[:2000]
    finally:
        job.processing_time = round(time.perf_counter() - started, 3)
        job.peak_memory_mb = round(sampler.peak_rss_mb, 1)
        job.cpu_percent = sampler.avg_cpu_percent
        db.commit()
        _log_job(job, started_at)
        db.close()


def _log_job(job: OCRJob, started_at: datetime) -> None:
    """Structured local log line — never includes document text."""
    fields = {
        "job_id": job.id,
        "status": job.status,
        "error_code": job.error_code,
        "engine": job.engine,
        "engine_version": job.engine_version,
        "device": job.device,
        "language": job.language,
        "pages": job.page_count,
        "start": started_at.isoformat(),
        "end": datetime.now(timezone.utc).isoformat(),
        "processing_time_s": job.processing_time,
        "peak_memory_mb": job.peak_memory_mb,
        "cpu_percent": job.cpu_percent,
        "mime": job.mime_type,
        "size_bytes": job.file_size,
    }
    job_logger().info(" ".join(f"{k}={v}" for k, v in fields.items()))


# ---------------------------------------------------------------- pipeline


def _run_pipeline(db: Session, job: OCRJob) -> None:
    storage = get_storage()
    options = dict(job.options or {})
    src_path = storage.path_for(f"uploads/{job.stored_filename}")
    work_dir = storage.path_for(f"processed/{job.id}")
    os.makedirs(work_dir, exist_ok=True)

    # 0) Disk guard.
    free_mb = disk_free_mb(work_dir)
    if free_mb < settings.MIN_FREE_DISK_MB:
        raise OCRError(ErrorCode.INSUFFICIENT_DISK_SPACE, detail=f"{free_mb:.0f} MB free, {settings.MIN_FREE_DISK_MB} MB required")

    # 1) Page extraction.
    raw_dir = os.path.join(work_dir, "raw")
    try:
        if preprocessing.is_pdf(job.filename, job.mime_type):
            raw_pages = preprocessing.render_pdf_pages(src_path, raw_dir)
        else:
            raw_pages = preprocessing.prepare_image_page(src_path, raw_dir)
    except OCRError:
        raise
    except Exception as exc:
        code = ErrorCode.CORRUPTED_PDF if preprocessing.is_pdf(job.filename, job.mime_type) else ErrorCode.CORRUPTED_IMAGE
        raise OCRError(code, detail=f"{type(exc).__name__}: {str(exc)[:200]}") from exc
    if not raw_pages:
        raise OCRError(ErrorCode.CORRUPTED_PDF, detail="document has no pages")

    # 2) Engines in preference order; runtime failures fail over to the next.
    #    Arabic/mixed documents prefer QARI when it is locally READY (auto only).
    requested_engine = options.get("engine") or settings.OCR_DEFAULT_ENGINE
    if options.get("device_preference") == "cuda":
        from app.services.hardware import gpu_available

        if not gpu_available():
            raise OCRError(ErrorCode.CUDA_UNAVAILABLE)
    language_opt = options.get("language") or "auto"
    lang_hint = None if normalize(language_opt) == AUTO else language_opt
    high_quality = bool(options.get("prefer_quality")) or (options.get("quality_mode") or "balanced") == "high"
    providers = resolve_providers_ordered(requested_engine, language=lang_hint, high_quality=high_quality)
    if not providers:
        raise OCRError(
            ErrorCode.ENGINE_UNAVAILABLE,
            detail=f"no READY engine (requested={requested_engine}); check System Health for missing local models",
        )
    provider = providers[0]
    job.engine = provider.name
    job.engine_version = provider.version()
    job.device = provider.device()

    language_opt = options.get("language") or "auto"
    ocr_language = language_opt  # "auto" → engines detect via OSD
    extract_opts = {
        "language": ocr_language,
        "quality_mode": options.get("quality_mode") or "balanced",
        "qari_mode": options.get("qari_mode") or "auto",
        "qari_version": options.get("qari_version"),
        "handwriting_detection": bool(options.get("handwriting_detection")),
    }
    preserve_layout = bool(options.get("preserve_layout", True))
    preserve_diacritics = bool(options.get("preserve_diacritics", True))
    preserve_punct = bool(options.get("preserve_punctuation", True))

    all_text: list[str] = []
    total_conf = 0.0
    conf_weight = 0
    structured: dict[str, Any] = {"tables": [], "fields": {}}

    all_region_specs = options.get("region_specs") or []
    processed_pages = 0
    job_tokens_out = 0  # honest token accounting for generative engines (throughput monitoring)

    for raw in raw_pages:
        page_no = raw["page_number"]
        page_regions = [r for r in all_region_specs if r.get("page_number") == page_no]

        # Selective OCR: pages without a selected region are intentionally skipped.
        if all_region_specs and not page_regions:
            continue
        processed_pages += 1

        # 3) Preprocess (orientation → deskew → denoise → contrast).
        processed_path = os.path.join(work_dir, f"page_{page_no}.png")
        meta = preprocessing.preprocess_page(
            raw["path"],
            processed_path,
            deskew=bool(options.get("deskew", True)),
            denoise=bool(options.get("denoise", True)),
            auto_rotate=bool(options.get("auto_rotate", True)),
            enhance_contrast=bool(options.get("enhance_contrast", True)),
        )

        # 4) OCR — region mode or full-page mode.
        page = OCRPage(
            job_id=job.id,
            page_number=page_no,
            width=meta["width"],
            height=meta["height"],
            image_path=f"processed/{job.id}/page_{page_no}.png",
        )
        db.add(page)
        db.flush()

        if page_regions:
            from PIL import Image as _PILImage

            img_w, img_h = meta["width"], meta["height"]
            region_texts = []
            page_conf_total = 0.0
            page_conf_weight = 0
            page_blocks: list = []

            for region in sorted(page_regions, key=lambda r: r.get("order", 0)):
                current_region_label = region.get("label", "")
                x1 = int(region["x"] * img_w)
                y1 = int(region["y"] * img_h)
                x2 = min(img_w, int((region["x"] + region["width"]) * img_w))
                y2 = min(img_h, int((region["y"] + region["height"]) * img_h))

                crop_path = os.path.join(work_dir, f"region_{page_no}_{current_region_label}.png")
                with _PILImage.open(meta["path"]) as img:
                    crop_img = img.crop((x1, y1, x2, y2))
                    crop_img.save(crop_path)

                crop_result = None
                last_exc: Optional[BaseException] = None
                for candidate in providers[providers.index(provider):]:
                    try:
                        crop_result = asyncio.run(candidate.extract(crop_path, extract_opts))
                        if candidate is not provider:
                            provider = candidate
                            job.engine = candidate.name
                            job.engine_version = candidate.version()
                            job.device = candidate.device()
                        break
                    except BaseException as exc:
                        last_exc = exc
                if crop_result is None:
                    err = classify_exception(last_exc) if last_exc else OCRError(ErrorCode.ENGINE_UNAVAILABLE)
                    raise OCRError(err.code, detail=f"all engines failed; last: {err.detail or err.message}")

                for b in crop_result.blocks:
                    if b.bbox:
                        b.bbox[0] += x1
                        b.bbox[2] += x1
                        b.bbox[1] += y1
                        b.bbox[3] += y1

                if crop_result.tokens_out:
                    job_tokens_out += crop_result.tokens_out

                region_text = reconstruct(crop_result.blocks, preserve_layout=preserve_layout) if crop_result.blocks else crop_result.text
                region_text = apply_preservation(region_text, preserve_diacritics=preserve_diacritics, preserve_punctuation=preserve_punct)
                region_texts.append(region_text)

                for b in crop_result.blocks:
                    db.add(
                        OCRBlock(
                            page_id=page.id,
                            text=apply_preservation(b.text, preserve_diacritics=preserve_diacritics, preserve_punctuation=preserve_punct),
                            confidence=round(b.confidence, 4) if b.confidence is not None else None,
                            bbox=b.bbox,
                            language=b.language,
                            block_type=b.block_type,
                            region_label=current_region_label,
                        )
                    )
                    page_blocks.append(b)

                n_blocks = len(crop_result.blocks)
                if crop_result.confidence is not None:
                    total_conf += crop_result.confidence * max(n_blocks, 1)
                    conf_weight += max(n_blocks, 1)
                    page_conf_total += crop_result.confidence * max(n_blocks, 1)
                    page_conf_weight += max(n_blocks, 1)
                if crop_result.warnings:
                    job_logger().warning("job=%s page=%d region=%s engine=%s warnings=%s", job.id, page_no, current_region_label, job.engine, crop_result.warnings)

            page_text = "\n\n".join(t for t in region_texts if t).strip()
            page.confidence = round(page_conf_total / page_conf_weight, 4) if page_conf_weight else None
        else:
            # 4) OCR with failover (full-page).
            result = None
            last_exc: Optional[BaseException] = None
            for candidate in providers[providers.index(provider):]:
                try:
                    result = asyncio.run(candidate.extract(meta["path"], extract_opts))
                    if candidate is not provider:
                        provider = candidate
                        job.engine = candidate.name
                        job.engine_version = candidate.version()
                        job.device = candidate.device()
                    break
                except BaseException as exc:  # noqa: BLE001
                    last_exc = exc
            if result is None:
                err = classify_exception(last_exc) if last_exc else OCRError(ErrorCode.ENGINE_UNAVAILABLE)
                raise OCRError(err.code, detail=f"all engines failed; last: {err.detail or err.message}")
            if result.tokens_out:
                job_tokens_out += result.tokens_out

            # 5) Text reconstruction + preservation options.
            page_text = reconstruct(result.blocks, preserve_layout=preserve_layout) if result.blocks else result.text
            page_text = apply_preservation(
                page_text, preserve_diacritics=preserve_diacritics, preserve_punctuation=preserve_punct
            )
            page.confidence = round(result.confidence, 4) if result.confidence is not None else None

            # 6) Persist blocks.
            for b in result.blocks:
                db.add(
                    OCRBlock(
                        page_id=page.id,
                        text=apply_preservation(
                            b.text, preserve_diacritics=preserve_diacritics, preserve_punctuation=preserve_punct
                        ),
                        confidence=round(b.confidence, 4) if b.confidence is not None else None,
                        bbox=b.bbox,
                        language=b.language,
                        block_type=b.block_type,
                    )
                )
            page_blocks = result.blocks

            if result.confidence is not None:
                total_conf += result.confidence * max(len(result.blocks), 1)
                conf_weight += max(len(result.blocks), 1)
            if result.warnings:
                job_logger().warning("job=%s page=%d engine=%s warnings=%s", job.id, page_no, job.engine, result.warnings)

        # 6b) Finalize page record.
        page.text = page_text

        # 7) Optional table detection.
        if options.get("detect_tables"):
            for t in table_extraction.detect_tables(meta["path"], page_blocks):
                t["page_number"] = page_no
                structured["tables"].append(t)

        all_text.append(page_text)
        db.flush()

    full_text = "\n\n".join(t for t in all_text if t).strip()
    job.text = full_text
    job.page_count = processed_pages
    job.tokens_processed = job_tokens_out or None
    job.confidence = round(total_conf / conf_weight, 4) if conf_weight else None

    # 8) Language from actual OCR output.
    resolved_language = detect_language(full_text)
    job.language = resolved_language

    # 9) Classification (user hint wins).
    if options.get("document_type"):
        job.document_type = options["document_type"]
        job.document_type_confidence = 1.0
    else:
        doc_type, doc_conf = classify_document(full_text, job.mime_type, job.page_count)
        job.document_type = doc_type
        job.document_type_confidence = doc_conf

    # 10) Structured field extraction.
    if options.get("structured_extraction", True):
        structured["fields"] = extract_structured_fields(full_text, job.document_type, resolved_language)
    job.structured_data = structured
    db.flush()

    # 10b) Persist region specs.
    for spec in all_region_specs:
        db.add(OCRRegion(
            job_id=job.id,
            page_number=spec["page_number"],
            label=spec.get("label", ""),
            x=spec["x"],
            y=spec["y"],
            width=spec["width"],
            height=spec["height"],
            order=spec.get("order", 0),
        ))
    db.flush()

    # 11) Temporary preprocessing images are removed after success.
    if not settings.KEEP_TEMP_FILES:
        shutil.rmtree(raw_dir, ignore_errors=True)


def _file_size(path: str) -> int:
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def delete_job_files(job: OCRJob) -> None:
    storage = get_storage()
    storage.delete(f"uploads/{job.stored_filename}")
    storage.delete_prefix(f"processed/{job.id}")

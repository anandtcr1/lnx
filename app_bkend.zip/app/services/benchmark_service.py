"""OCR Lab: run ONE document through several engines and record real measurements.

CER/WER are computed only when ground truth is supplied. Confidence is reported
separately and is never presented as accuracy.
"""

import asyncio
import os
import shutil
import time
from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import SessionLocal
from app.core.errors import classify_exception
from app.models.models import Benchmark
from app.providers.ocr import engine_statuses, get_provider, provider_names
from app.services import metrics, preprocessing
from app.services.resource_monitor import ResourceSampler
from app.storage import get_storage

# OCR Lab engine tokens: plain provider names plus QARI version variants so the
# Lab can compare QARI v0.2 vs v0.3 on the same document.
LAB_TOKENS = ("qari", "qari:v0.2", "qari:v0.3")


def create_benchmark(
    db: Session,
    filename: str,
    mime_type: str,
    stored_filename: str,
    engines: list[str],
    ground_truth: Optional[str],
    language: str,
) -> Benchmark:
    valid = [e for e in engines if e in provider_names() or e in LAB_TOKENS] or provider_names()
    bench = Benchmark(
        filename=filename,
        stored_filename=stored_filename,
        mime_type=mime_type,
        ground_truth=(ground_truth or "").strip() or None,
        language=language,
        engines=valid,
        status="pending",
    )
    db.add(bench)
    db.commit()
    db.refresh(bench)
    return bench


def enqueue_benchmark(benchmark_id: str) -> None:
    if settings.WORKER_MODE == "celery":
        from app.workers.tasks import run_benchmark_task

        run_benchmark_task.delay(benchmark_id)
    else:
        import threading

        threading.Thread(target=run_benchmark, args=(benchmark_id,), daemon=True).start()


def run_benchmark(benchmark_id: str) -> None:
    db = SessionLocal()
    bench = db.get(Benchmark, benchmark_id)
    if bench is None:
        db.close()
        return
    bench.status = "processing"
    db.commit()

    storage = get_storage()
    work_dir = storage.path_for(f"processed/benchmarks/{bench.id}")
    try:
        src = storage.path_for(f"uploads/{bench.stored_filename}")
        raw_dir = os.path.join(work_dir, "raw")
        if preprocessing.is_pdf(bench.filename, bench.mime_type):
            raw_pages = preprocessing.render_pdf_pages(src, raw_dir)[:1]  # first page only in the Lab
        else:
            raw_pages = preprocessing.prepare_image_page(src, raw_dir)
        processed = preprocessing.preprocess_page(raw_pages[0]["path"], os.path.join(work_dir, "page_1.png"))

        statuses = {s["name"]: s for s in engine_statuses()}
        language = bench.language or "auto"
        results: list[dict[str, Any]] = []
        for name in bench.engines:
            results.append(_run_engine(name, statuses.get(name.split(":")[0], {}), processed["path"], language, bench.ground_truth))
        bench.results = results
        bench.status = "completed"
    except BaseException as exc:  # noqa: BLE001
        err = classify_exception(exc)
        bench.status = "failed"
        bench.error = err.public_message(settings.is_development)[:2000]
    finally:
        bench.completed_at = datetime.now(timezone.utc)
        db.commit()
        db.close()
        if not settings.KEEP_TEMP_FILES:
            shutil.rmtree(os.path.join(work_dir, "raw"), ignore_errors=True)


def _run_engine(name: str, status: dict, image_path: str, language: str, ground_truth: Optional[str]) -> dict:
    provider_name = name.split(":")[0]
    status = status or {}
    base: dict[str, Any] = {
        "engine": name,
        "version": status.get("version"),
        "device": status.get("device", "cpu"),
        "status": "SKIPPED",
        "reason": None,
        "time": None,
        "peak_memory_mb": None,
        "cpu_percent": None,
        "confidence": None,
        "blocks": 0,
        "text": None,
        "cer": None,
        "wer": None,
        "cer_no_diacritics": None,
        "wer_no_diacritics": None,
    }
    if status.get("status") != "READY":
        base["reason"] = status.get("reason") or status.get("status") or "engine unavailable"
        return base

    provider = get_provider(provider_name)
    if provider is None:
        base["reason"] = "engine failed to initialize"
        return base

    options: dict[str, Any] = {"language": language, "quality_mode": "balanced", "qari_mode": "auto"}
    if name == "qari:v0.2":
        options["qari_version"] = "v0.2"
        options["qari_mode"] = "printed"
    elif name == "qari:v0.3":
        options["qari_version"] = "v0.3"
        options["qari_mode"] = "handwritten"

    sampler = ResourceSampler(interval=0.25)
    started = time.perf_counter()
    try:
        with sampler:
            result = asyncio.run(provider.extract(image_path, options))
        base.update(
            status="OK",
            time=round(time.perf_counter() - started, 3),
            peak_memory_mb=round(sampler.peak_rss_mb, 1),
            cpu_percent=sampler.avg_cpu_percent,
            confidence=round(result.confidence, 4) if result.confidence is not None else None,
            blocks=len(result.blocks),
            text=result.text,
            device=provider.device(),
            version=provider.version(),
        )
        if ground_truth:
            base.update(metrics.evaluate(ground_truth, result.text or ""))
    except BaseException as exc:  # noqa: BLE001
        err = classify_exception(exc)
        base.update(
            status="FAIL",
            reason=f"{err.code.value}: {err.detail or err.message}"[:300],
            time=round(time.perf_counter() - started, 3),
            peak_memory_mb=round(sampler.peak_rss_mb, 1),
        )
    return base

"""Script/language detection for Arabic, CJK, Cyrillic, Latin and more.

``detect_script`` is per-block (best-effort canonical language code), while
``detect_language`` is document-level and uses ``langdetect`` to tell Latin
languages apart. ``detect_image_language`` uses Tesseract OSD for the "auto"
mode when no text is available yet.
"""

from typing import Optional

from app.services.languages import direction as _direction
from app.services.languages import normalize, script_to_language

# codepoint ranges per script (inclusive)
_RANGES: dict[str, tuple[tuple[int, int], ...]] = {
    "arabic": (
        (0x0600, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF),
        (0xFB50, 0xFDFF), (0xFE70, 0xFEFF),
    ),
    "latin": ((0x0041, 0x005A), (0x0061, 0x007A), (0x00C0, 0x024F), (0x1E00, 0x1EFF)),
    "han": ((0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2A6DF)),
    "cyrillic": ((0x0400, 0x04FF), (0x0500, 0x052F)),
    "devanagari": ((0x0900, 0x097F), (0xA8E0, 0xA8FF)),
    "hangul": ((0x1100, 0x11FF), (0x3130, 0x318F), (0xAC00, 0xD7AF)),
    "kana": ((0x3040, 0x309F), (0x30A0, 0x30FF)),
    "greek": ((0x0370, 0x03FF), (0x1F00, 0x1FFF)),
    "hebrew": ((0x0590, 0x05FF), (0xFB1D, 0xFB4F)),
    "thai": ((0x0E00, 0x0E7F),),
    "bengali": ((0x0980, 0x09FF),),
    "tamil": ((0x0B80, 0x0BFF),),
    "telugu": ((0x0C00, 0x0C7F),),
    "kannada": ((0x0C80, 0x0CFF),),
}

_SCRIPT_LANGUAGE = {
    "arabic": "ar",
    "latin": "en",
    "han": "zh-Hans",
    "cyrillic": "ru",
    "devanagari": "hi",
    "hangul": "ko",
    "kana": "ja",
    "greek": "el",
    "hebrew": "he",
    "thai": "th",
    "bengali": "en",
    "tamil": "en",
    "telugu": "en",
    "kannada": "en",
}

_LATIN_LANGUAGES = {"fr", "de", "es", "it", "pt", "nl", "pl", "sv", "tr", "vi", "id"}

_MIXED_MIN_RATIO = 0.2
_LATIN_MIN_LETTERS = 20  # below this, langdetect is unreliable on OCR noise


def _script_of(ch: str) -> Optional[str]:
    code = ord(ch)
    for script, ranges in _RANGES.items():
        for start, end in ranges:
            if start <= code <= end:
                return script
    return None


def script_counts(text: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for ch in text or "":
        script = _script_of(ch)
        if script is not None:
            counts[script] = counts.get(script, 0) + 1
    return counts


def _dominant(counts: dict[str, int]) -> Optional[str]:
    if not counts:
        return None
    return max(counts.items(), key=lambda kv: kv[1])[0]


def detect_script(text: str) -> str:
    """Per-block language: canonical code, or 'mixed' for Arabic + Latin."""
    counts = script_counts(text or "")
    total = sum(counts.values())
    if total == 0:
        return "en"
    arabic = counts.get("arabic", 0)
    latin = counts.get("latin", 0)
    if arabic / total >= _MIXED_MIN_RATIO and latin / total >= _MIXED_MIN_RATIO:
        return "mixed"
    script = _dominant(counts)
    return _SCRIPT_LANGUAGE.get(script or "", "en")


def _detect_latin_language(text: str) -> Optional[str]:
    try:
        from langdetect import DetectorFactory, detect

        DetectorFactory.seed = 0
        code = normalize(detect(text))
        if code in _LATIN_LANGUAGES:
            return code
    except Exception:
        pass
    return None


def detect_language(text: str) -> str:
    """Document-level language: canonical code, or 'mixed' for Arabic + Latin."""
    counts = script_counts(text or "")
    total = sum(counts.values())
    if total == 0:
        return "en"
    arabic = counts.get("arabic", 0)
    latin = counts.get("latin", 0)
    if arabic / total >= _MIXED_MIN_RATIO and latin / total >= _MIXED_MIN_RATIO:
        return "mixed"
    script = _dominant(counts) or "latin"
    if script == "latin":
        if sum(1 for ch in text if ch.isalpha()) < _LATIN_MIN_LETTERS:
            return "en"  # too little text for langdetect to be trusted
        return _detect_latin_language(text) or "en"
    return _SCRIPT_LANGUAGE.get(script, "en")


def detect_image_language(file_path: str, probe_langs: str = "eng+ara+chi_sim") -> Optional[str]:
    """Best-effort language guess for an image (used by the "auto" mode).

    Tries Tesseract OSD first; if the page has too little text for OSD, falls
    back to a cheap OCR probe and detects the language from the text. Returns
    None when nothing conclusive is found (caller applies its own default).
    """
    try:
        import pytesseract

        osd = pytesseract.image_to_osd(file_path)
        for line in str(osd).splitlines():
            if line.lower().startswith("script:"):
                guess = script_to_language(line.split(":", 1)[1].strip())
                if guess:
                    return guess
    except Exception:
        pass
    try:
        import pytesseract
    except Exception:
        return None
    text = ""
    for langs in (probe_langs, "eng"):
        try:
            text = pytesseract.image_to_string(file_path, lang=langs)
        except Exception:
            continue
        if (text or "").strip():
            break
    if not text.strip():
        return None
    return detect_language(text)


def text_direction(language: str) -> str:
    return _direction(language)

"""Bordered-table detection with OpenCV + assignment of OCR blocks to cells.

Detects ruling lines, builds a row/column grid, then maps each OCR block to
its cell by bbox center. Works well for government forms and invoices that
use visible borders.
"""

import html
from typing import Any, Optional

import cv2
import numpy as np


def _cluster(values: list[float], tolerance: float = 8.0) -> list[float]:
    """Cluster near-duplicate coordinates (line thickness) into single positions."""
    if not values:
        return []
    values = sorted(values)
    clusters = [[values[0]]]
    for v in values[1:]:
        if v - clusters[-1][-1] <= tolerance:
            clusters[-1].append(v)
        else:
            clusters.append([v])
    return [sum(c) / len(c) for c in clusters]


def detect_tables(image_path: str, blocks: list[Any]) -> list[dict]:
    """Return a list of tables: {"headers": [...], "rows": [[...], ...]}."""
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        return []

    binary = cv2.adaptiveThreshold(
        ~img, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 15, -2
    )

    h_kernel_len = max(10, img.shape[1] // 40)
    v_kernel_len = max(10, img.shape[0] // 40)
    horizontal = cv2.morphologyEx(binary, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (h_kernel_len, 1)))
    vertical = cv2.morphologyEx(binary, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (1, v_kernel_len)))

    h_proj = (horizontal > 0).sum(axis=1)
    v_proj = (vertical > 0).sum(axis=0)

    h_lines = np.where(h_proj > img.shape[1] * 0.15)[0].tolist()
    v_lines = np.where(v_proj > img.shape[0] * 0.15)[0].tolist()

    rows_y = _cluster([float(y) for y in h_lines])
    cols_x = _cluster([float(x) for x in v_lines])

    if len(rows_y) < 2 or len(cols_x) < 2:
        return []

    n_rows = len(rows_y) - 1
    n_cols = len(cols_x) - 1
    grid: list[list[list[str]]] = [[[] for _ in range(n_cols)] for _ in range(n_rows)]

    def _find_index(positions: list[float], value: float) -> Optional[int]:
        for i in range(len(positions) - 1):
            if positions[i] <= value <= positions[i + 1]:
                return i
        return None

    for block in blocks:
        bbox = getattr(block, "bbox", None) or (block.get("bbox") if isinstance(block, dict) else None)
        text = getattr(block, "text", None) or (block.get("text") if isinstance(block, dict) else "")
        if not bbox or not text:
            continue
        cx = (bbox[0] + bbox[2]) / 2
        cy = (bbox[1] + bbox[3]) / 2
        r = _find_index(rows_y, cy)
        c = _find_index(cols_x, cx)
        if r is not None and c is not None:
            grid[r][c].append(text)

    text_grid = [[" ".join(cell).strip() for cell in row] for row in grid]

    # Drop fully empty outer rows/cols produced by double borders.
    text_grid = [row for row in text_grid if any(row)]
    if not text_grid:
        return []
    keep_cols = [i for i in range(n_cols) if any(i < len(row) and row[i] for row in text_grid)]
    text_grid = [[row[i] if i < len(row) else "" for i in keep_cols] for row in text_grid]

    if not text_grid or not text_grid[0]:
        return []

    return [{"headers": text_grid[0], "rows": text_grid[1:]}]


def table_to_html(table: dict) -> str:
    headers = "".join(f"<th>{html.escape(h)}</th>" for h in table.get("headers", []))
    rows = "".join(
        "<tr>" + "".join(f"<td>{html.escape(str(cell))}</td>" for cell in row) + "</tr>"
        for row in table.get("rows", [])
    )
    return f"<table><thead><tr>{headers}</tr></thead><tbody>{rows}</tbody></table>"

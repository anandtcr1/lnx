# LDAP login: audit logging & HTTP 500 error logging

Changes of **2026-11-01** to the Active Directory (LDAP) login of the Custom OCR backend.

1. **Login attempt audit log:** every LDAP login attempt (success, failure or error) writes one line to a dedicated rotating file `ldap_login.log`, with the result, user name, client IP and reason. Passwords are never logged.
2. **Detailed error logging (HTTP 500):** a login that failed with a bare HTTP 500 now logs the exception type, message and full traceback. LDAP connection, bind and search failures are logged with Active Directory's own reason code. The 500 response names the exception type.

No new Python packages, environment variables or database changes are needed.

---

## Contents of this folder

The files are complete copies of the final versions, at the same paths as in the project:

```
ldap_chages/
├── README.md                          (this file)
└── backend/app/
    ├── core/logging_config.py         modified
    ├── api/v1/auth.py                 modified
    └── services/ldap_service.py       modified
```

> **Before copying whole files:** `auth.py` and `ldap_service.py` also contain the earlier login / user-management work (see `LoginUserManagementChanges.md`). Copy them over only if the office versions already contain that work. Otherwise apply the changes function by function as described below.

---

## Apply in the office environment

1. Copy the three files into `backend/app/...`, replacing the existing ones (or apply the changes below by hand).
2. Restart the backend.
3. Log in with an AD user, then open the log file:
   - `<LOGS_PATH>/ldap_login.log`, or, when `LOGS_PATH` is empty,
   - `<STORAGE_PATH>/logs/ldap_login.log` (default `backend/storage/logs/ldap_login.log`).
4. For an HTTP 500, find the `result=ERROR` line and the traceback below it. The same traceback is also printed on the backend console.

---

## Summary of changes

| File | Function / item | Status | Change |
|---|---|---|---|
| `backend/app/core/logging_config.py` | `configure_logging()` | Modified | Adds the rotating `ldap_login.log` handler and attaches it to the `ocr.ldap` logger too. |
| | `LDAP_LOGIN_LOGGER`, `LDAP_LOGIN_LOG_FILE` | New | Logger name / file name constants. |
| | `ldap_login_logger()` | New | Returns the audit logger. |
| `backend/app/api/v1/auth.py` | import, `_CONTROL_CHARS` | New | Imports `ldap_login_logger`; regex used to clean user-supplied text. |
| | `_log_ldap_login()` | New | Writes one audit line, plus the traceback when given an exception. |
| | `login()` | Modified | Takes `request`; wraps `_login()` and logs any unexpected exception in full, returning a descriptive 500. |
| | `_login()` | New | The previous body of `login()`, plus an audit log call for each LDAP outcome. |
| `backend/app/services/ldap_service.py` | `_server()` | Modified | Debug line with server, host and timeout. |
| | `_bind()` | Modified | Logs connection errors with a traceback, and rejected binds with AD's reason code. |
| | `_safe_unbind()` | New | An unbind that never hides the original error. |
| | `_describe()` | New | Formats ldap3's `conn.result` for the log. |
| | `_search()` | Modified | Debug line with the base DN and filter; error lines on failure. |
| | `find_user()` | Modified | Warning when 0 or more than 1 account matches; debug line with the resolved DN. |
| | `authenticate()` | Modified | Warning on an empty password; info line when the password is verified. |
| | `search_users()`, `directory_domains()` | Modified | `conn.unbind()` replaced by `_safe_unbind(conn)`. |

---

## The log file `ldap_login.log`

| | |
|---|---|
| Location | `<LOGS_PATH>/ldap_login.log` (default `backend/storage/logs/ldap_login.log`) |
| Rotation | 10 MB per file, 10 backups (`ldap_login.log.1` … `.10`), UTF-8 |
| Contents | One audit line per LDAP login attempt (logger `ocr.auth.ldap_login`, file only), plus INFO/WARNING/ERROR diagnostics from the LDAP service (logger `ocr.ldap`, also on the console). |
| Not included | Local accounts (`administrator`, the first-run admin) and Windows SSO sign-ins. Passwords are never written. |
| Security | Control characters (e.g. new lines) in the user name and reason are replaced, so a crafted user name cannot forge extra log lines. The user name is limited to 128 characters and the reason to 500. |

### Audit line format

```
<timestamp> result=<SUCCESS|FAILED|ERROR> user=<login name> ip=<client IP> reason=<reason or ->
```

| Situation | result | reason | HTTP |
|---|---|---|---|
| Password accepted by AD, user enabled | SUCCESS | `-` | 200 |
| User not registered in the application | FAILED | not registered in the application | 401 |
| Local account entered as `DOMAIN\name` | FAILED | local account, AD-style login refused | 401 |
| AD rejected the credentials | FAILED | AD rejected credentials (wrong password, disabled or removed) | 401 |
| User disabled in the application | FAILED | disabled in the application | 403 |
| AD unreachable / misconfigured | ERROR | Active Directory unavailable: `<details>` | 503 |
| Any unexpected exception | ERROR | unexpected `<module.ExceptionType>: <message>`, plus the full traceback | 500 |

### Sample

```
2026-11-01 15:30:30,843 result=SUCCESS user=jdoe ip=10.1.2.3 reason=-
2026-11-01 15:34:53,820 LDAP - bind rejected for CN=John Doe,DC=dev: result=49 description=invalidCredentials message=80090308: LdapErr: DSID-0C09044E, comment: AcceptSecurityContext error, data 52e, v4563
2026-11-01 15:34:53,821 result=FAILED user=jdoe ip=10.1.2.3 reason=AD rejected credentials (wrong password, disabled or removed)
2026-11-01 15:34:53,837 LDAP - cannot reach ldap://dev.team.ae while binding as svc: ldap3.core.exceptions.LDAPSocketOpenError: socket connection error while opening: timed out
Traceback (most recent call last):
  ...
2026-11-01 15:34:53,837 result=ERROR user=jdoe ip=10.1.2.3 reason=Active Directory unavailable: Active Directory is unreachable (ldap://dev.team.ae): socket connection error while opening: timed out
2026-11-01 15:34:53,509 result=ERROR user=jdoe ip=10.1.2.3 reason=unexpected builtins.KeyError: 'defaultNamingContext'
Traceback (most recent call last):
  File "...\app\api\v1\auth.py", line 146, in login
  ...
KeyError: 'defaultNamingContext'
```

### Active Directory reason codes

A "bind rejected" line contains AD's message. The code after `data` tells why the login failed:

| Code | Meaning | Code | Meaning |
|---|---|---|---|
| `52e` | Wrong password | `533` | Account disabled |
| `525` | User not found | `701` | Account expired |
| `530` | Not permitted to log on at this time | `773` | User must change password |
| `531` | Not permitted to log on from this workstation | `775` | Account locked out |
| `532` | Password expired | | |

---

## Changes by file

### 1. `backend/app/core/logging_config.py`

#### `configure_logging()` (modified)

This block was added after the job-log handler (`job_logger.addHandler(handler)`), before `_configured = True`:

**File:** `backend/app/core/logging_config.py` → `configure_logging()` (modified)

```python
# File: backend/app/core/logging_config.py
    # Audit trail of every Active Directory (LDAP) login attempt. File only, never passwords.
    login_logger = logging.getLogger(LDAP_LOGIN_LOGGER)
    login_logger.setLevel(logging.INFO)
    login_logger.propagate = False
    login_handler = RotatingFileHandler(
        os.path.join(settings.logs_path, LDAP_LOGIN_LOG_FILE),
        maxBytes=10 * 1024 * 1024,
        backupCount=10,
        encoding="utf-8",
    )
    login_handler.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
    login_handler.setLevel(logging.INFO)
    login_logger.addHandler(login_handler)
    # LDAP diagnostics (bind rejections with AD's reason code, connection / search
    # errors with tracebacks) go to the same file as well as the console.
    logging.getLogger("ocr.ldap").addHandler(login_handler)
```

- `propagate = False`: audit lines go to the file only, not the console.
- One handler is shared by both loggers. One handler per file keeps rotation working on Windows.

#### New constants and `ldap_login_logger()`

These go after `configure_logging()`:

**File:** `backend/app/core/logging_config.py` → new constants (after `configure_logging()`)

```python
# File: backend/app/core/logging_config.py
LDAP_LOGIN_LOGGER = "ocr.auth.ldap_login"
LDAP_LOGIN_LOG_FILE = "ldap_login.log"
```

**File:** `backend/app/core/logging_config.py` → new function `ldap_login_logger()`

```python
# File: backend/app/core/logging_config.py
def ldap_login_logger() -> logging.Logger:
    return logging.getLogger(LDAP_LOGIN_LOGGER)
```

---

### 2. `backend/app/api/v1/auth.py`

#### New import (with the other `app.core` imports)

**File:** `backend/app/api/v1/auth.py` → New import (with the other `app.core` imports)

```python
# File: backend/app/api/v1/auth.py
from app.core.logging_config import ldap_login_logger
```

#### New constant and `_log_ldap_login()` (above `login()`)

**File:** `backend/app/api/v1/auth.py` → New constant and `_log_ldap_login()` (above `login()`)

```python
# File: backend/app/api/v1/auth.py
_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")


def _log_ldap_login(
    request: Request, username: str, result: str, reason: str = "", exc: Optional[BaseException] = None
) -> None:
    """One line per AD login attempt in <LOGS_PATH>/ldap_login.log. Never logs the password.

    When `exc` is given the full traceback is written below the line.
    """
    # The user name is attacker-controlled: strip control characters so it can't forge log lines.
    name = _CONTROL_CHARS.sub("?", username or "")[:128] or "-"
    reason = _CONTROL_CHARS.sub(" ", reason or "")[:500] or "-"
    ip = request.client.host if request.client else "-"
    level = logging.ERROR if exc is not None else logging.INFO
    ldap_login_logger().log(
        level, "result=%s user=%s ip=%s reason=%s", result, name, ip, reason, exc_info=exc
    )
```

#### `login()` (modified): catches unexpected errors (the HTTP 500 fix)

- It now takes `request: Request`, needed for the client IP.
- Its old body moved, unchanged, into `_login()`.
- `HTTPException` (401/403/503) passes through as before.
- Any other exception is logged with its full traceback, to the console and to `ldap_login.log`. The client gets a 500 that names the exception type.

**File:** `backend/app/api/v1/auth.py` → `login()` (modified): catches unexpected errors (the HTTP 500 fix)

```python
# File: backend/app/api/v1/auth.py
@router.post("/login")
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)) -> dict:
    try:
        return _login(payload, request, db)
    except HTTPException:
        raise  # expected outcomes (401/403/503), already logged
    except Exception as exc:
        # Unexpected failure (would otherwise be a bare 500): log the full traceback
        # to the console and to ldap_login.log.
        logger.exception("AUTH - unexpected error during login of %r", payload.username)
        _log_ldap_login(
            request, payload.username, "ERROR", f"unexpected {type(exc).__module__}.{type(exc).__name__}: {exc}", exc
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Login failed because of a server error ({type(exc).__name__}). See ldap_login.log for details.",
        ) from exc
```

#### `_login()` (new): the previous `login()` body with audit calls

The local-account branch is unchanged. In the LDAP branch, one `_log_ldap_login()` call was added before each outcome (marked `# NEW` below):

**File:** `backend/app/api/v1/auth.py` → `_login()` (new): the previous `login()` body with audit calls

```python
# File: backend/app/api/v1/auth.py
def _login(payload: LoginRequest, request: Request, db: Session) -> dict:
    # Local accounts are verified here, never against AD.
    user = find_user(db, payload.username) if payload.username.strip() else None
    if user is not None and is_local(user):
        ...  # unchanged
        return _session(user)

    # Everyone else must exist in our DB (added by an admin) AND in AD.
    username = ldap_service.normalize_username(payload.username)
    user = find_user(db, username) if username else None
    if user is None:
        logger.warning("AUTH - login refused, %s is not registered in the application", username)
        _log_ldap_login(request, username or payload.username, "FAILED", "not registered in the application")  # NEW
        raise _invalid()
    if is_local(user):
        logger.warning("AUTH - %s is a local account; AD-style login refused", user.username)
        _log_ldap_login(request, payload.username, "FAILED", "local account, AD-style login refused")  # NEW
        raise _invalid()
    try:
        ad_user = ldap_service.authenticate(username, payload.password)
    except ldap_service.LdapError as exc:
        logger.error("AUTH - AD unavailable during login of %s: %s", username, exc)
        _log_ldap_login(request, username, "ERROR", f"Active Directory unavailable: {exc}")  # NEW
        raise HTTPException(...) from exc  # 503, unchanged
    if ad_user is None:
        logger.warning("AUTH - AD rejected login for %s (wrong password, disabled or removed)", username)
        _log_ldap_login(request, username, "FAILED", "AD rejected credentials (wrong password, disabled or removed)")  # NEW
        raise _invalid()
    if not user.enabled:
        logger.warning("AUTH - login refused, %s is disabled in the application", user.username)
        _log_ldap_login(request, user.username, "FAILED", "disabled in the application")  # NEW
        raise _disabled()
    ...  # display-name sync unchanged
    _log_ldap_login(request, user.username, "SUCCESS")  # NEW
    return _session(user)
```

---

### 3. `backend/app/services/ldap_service.py`

#### `_server()` (modified)

A debug line was added before `return Server(...)`:

**File:** `backend/app/services/ldap_service.py` → `_server()` (modified)

```python
# File: backend/app/services/ldap_service.py
    logger.debug("LDAP - server %s (host %s, timeout %ss)", settings.LDAP_SERVER, host, settings.LDAP_TIMEOUT_S)
```

#### `_bind()` (modified)

Everything from the `try:` onwards was replaced:

**File:** `backend/app/services/ldap_service.py` → `_bind()` (modified)

```python
# File: backend/app/services/ldap_service.py
    try:
        conn.open()
        if settings.LDAP_USE_STARTTLS:
            conn.start_tls()
        if conn.bind():
            logger.debug("LDAP - bind OK as %s", user)
            return conn
    except (LDAPException, OSError) as exc:
        logger.error(
            "LDAP - cannot reach %s while binding as %s: %s.%s: %s",
            settings.LDAP_SERVER, user, type(exc).__module__, type(exc).__name__, exc, exc_info=True,
        )
        _safe_unbind(conn)
        raise LdapError(f"Active Directory is unreachable ({settings.LDAP_SERVER}): {exc}") from exc
    # AD's diagnostic text says why, e.g. "AcceptSecurityContext error, data 52e" (52e = wrong
    # password, 525 = no such user, 530/531 = logon time/workstation, 532 = password expired,
    # 533 = disabled, 701 = account expired, 773 = must change password, 775 = locked out).
    logger.warning("LDAP - bind rejected for %s: %s", user, _describe(conn.result))
    _safe_unbind(conn)
    return None
```

#### `_safe_unbind()` and `_describe()` (new, after `_bind()`)

**File:** `backend/app/services/ldap_service.py` → `_safe_unbind()` and `_describe()` (new, after `_bind()`)

```python
# File: backend/app/services/ldap_service.py
def _safe_unbind(conn: Connection) -> None:
    try:
        conn.unbind()
    except Exception:  # closing a broken socket must not hide the real error
        logger.debug("LDAP - unbind failed", exc_info=True)


def _describe(result: Optional[dict]) -> str:
    result = result or {}
    return (
        f"result={result.get('result')} description={result.get('description')} "
        f"message={(result.get('message') or '').strip() or '-'}"
    )
```

#### `_search()` (modified)

**File:** `backend/app/services/ldap_service.py` → `_search()` (modified)

```python
# File: backend/app/services/ldap_service.py
    logger.debug("LDAP - search base=%s filter=%s", _base_dn(conn), condition)   # NEW, before try:
    ...
    except (LDAPException, OSError) as exc:
        logger.error("LDAP - search failed (%s): %s.%s: %s", condition, type(exc).__module__, type(exc).__name__, exc,
                     exc_info=True)                                              # NEW
        raise LdapError(f"Active Directory search failed: {exc}") from exc
    if not ok and conn.result.get("result") not in (0, 4):
        logger.error("LDAP - search failed (%s): %s", condition, _describe(conn.result))   # NEW
        raise LdapError(f"Active Directory search failed: {conn.result.get('description')}")
```

#### `find_user()` (modified)

**File:** `backend/app/services/ldap_service.py` → `find_user()` (modified)

```python
# File: backend/app/services/ldap_service.py
    try:
        found = _search(conn, f"(sAMAccountName={name})", 2)
    finally:
        _safe_unbind(conn)
    if len(found) != 1:
        logger.warning("LDAP - %s: %d enabled AD account(s) found (expected 1)", name, len(found))
        return None
    logger.debug("LDAP - %s resolved to %s", name, found[0].dn)
    return found[0]
```

#### `authenticate()` (modified)

**File:** `backend/app/services/ldap_service.py` → `authenticate()` (modified)

```python
# File: backend/app/services/ldap_service.py
    if not password:
        logger.warning("LDAP - login of %s refused: empty password", username)   # NEW
        return None
    user = find_user(username)
    if user is None:
        return None
    conn = _bind(_server(), user.dn, password)
    if conn is None:
        return None
    _safe_unbind(conn)                                                            # was conn.unbind()
    logger.info("LDAP - password verified for %s", user.username)                # NEW
    return user
```

#### `search_users()`, `directory_domains()` (modified)

The only change: `conn.unbind()` in the `finally:` block became `_safe_unbind(conn)`.

---

## Notes

- **Client IP behind a reverse proxy:** behind nginx or another proxy, `ip=` shows the proxy's address unless uvicorn is started with `--proxy-headers` and `--forwarded-allow-ips=<proxy IP>`.
- **Debug lines:** the `LDAP - …` DEBUG lines (search filter, resolved DN, bind OK) appear only on the console, and only when `APP_ENV=development`. The file receives INFO and above.

## Verification

Tested with FastAPI `TestClient`, a temporary database and a mocked ldap3 connection:

| Test | Response | Log |
|---|---|---|
| Correct password | 200 | `result=SUCCESS` |
| Wrong password (bind rejected, `data 52e`) | 401 | "bind rejected" line with the AD message, plus `result=FAILED` |
| Unregistered user | 401 | `result=FAILED … not registered in the application` |
| User name containing a new line | 401 | Single line; the new line replaced by `?` |
| AD socket timeout | 503 | "cannot reach" line with the `LDAPSocketOpenError` traceback, plus `result=ERROR` |
| Forced `KeyError` inside AD code | 500 naming `KeyError` | `result=ERROR … unexpected builtins.KeyError`, plus the full traceback |

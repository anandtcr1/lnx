import base64
import binascii
import logging
import re
import threading
from typing import Optional

import spnego
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from spnego.exceptions import SpnegoError
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import SessionLocal, get_db
from app.core.logging_config import ldap_login_logger
from app.core.security import create_access_token, current_identity, hash_password, verify_password
from app.models.models import User
from app.services import ldap_service

logger = logging.getLogger("ocr.auth")

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginRequest(BaseModel):
    username: str
    password: str


class SetupRequest(BaseModel):
    username: str
    password: str


USERNAME_RE = re.compile(r"[A-Za-z0-9._-]{3,64}")
MIN_PASSWORD_LENGTH = 6
_setup_lock = threading.Lock()


def find_user(db: Session, username: str) -> Optional[User]:
    """Case-insensitive lookup — AD login names are case-insensitive."""
    return db.query(User).filter(func.lower(User.username) == username.strip().lower()).first()


def is_local(user: User) -> bool:
    """Local accounts (first-run setup / ADMIN_PASSWORD seed) use a local password, never AD."""
    return (user.auth_source or "") == "local"


def setup_required(db: Session) -> bool:
    """First-run state: no users at all -> the UI shows the "create administrator" screen."""
    return db.query(User.id).first() is None


def ensure_admin(db: Session) -> Optional[str]:
    """Seed/repair a local administrator from ADMIN_USERNAME / ADMIN_PASSWORD (idempotent).

    Only runs when ADMIN_PASSWORD is set; the stored hash is then re-synced on
    every start. When it is empty nothing is seeded and, while the users table
    is empty, the first-run setup screen creates the first administrator.
    """
    password = settings.ADMIN_PASSWORD or ""
    if not password.strip():
        if setup_required(db):
            logger.warning("ADMIN - no users yet: open the web app to create the first administrator")
        return None

    username = (settings.ADMIN_USERNAME or "administrator").strip()
    user = find_user(db, username)
    if user is not None:
        user.auth_source = "local"
        user.is_admin = True
        if not verify_password(password, user.hashed_password):
            user.hashed_password = hash_password(password)
            logger.info("ADMIN - password for %s re-synced from ADMIN_PASSWORD", user.username)
        db.commit()
        return user.username

    db.add(
        User(
            username=username,
            email=f"{username}@local",
            hashed_password=hash_password(password),
            is_admin=True,
            auth_source="local",
            display_name="Local administrator",
        )
    )
    db.commit()
    logger.info("ADMIN - local administrator created. username=%s (password from ADMIN_PASSWORD)", username)
    return username


def backfill_user_flags(db: Session) -> None:
    """Rows created before users.is_active existed are active."""
    count = db.query(User).filter(User.is_active.is_(None)).update({User.is_active: True})
    if count:
        db.commit()
        logger.info("USERS - marked %d existing user(s) as active", count)


def ensure_admin_once() -> Optional[str]:
    with SessionLocal() as db:
        backfill_user_flags(db)
        return ensure_admin(db)


def _invalid() -> HTTPException:
    return HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid username or password.")


def _disabled() -> HTTPException:
    # Only raised after the credentials were verified, so it reveals nothing to a guesser.
    return HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="This account is disabled. Contact the administrator.",
    )


_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")


def _log_ldap_login(
    request: Request, username: str, result: str, reason: str = "", exc: Optional[BaseException] = None
) -> None:
    """One line per AD login attempt in <LOGS_PATH>/ldap_login.log. Never logs the password.

    When `exc` is given the full traceback is written below the line.
    """
    # The user name is attacker-controlled: strip control characters so it can't forge log lines.
    name = _CONTROL_CHARS.sub("?", username or "")[:128] or "-"
    reason = _CONTROL_CHARS.sub(" ", reason or "")[:500] or "-"
    ip = request.client.host if request.client else "-"
    level = logging.ERROR if exc is not None else logging.INFO
    ldap_login_logger().log(
        level, "result=%s user=%s ip=%s reason=%s", result, name, ip, reason, exc_info=exc
    )


@router.post("/login")
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)) -> dict:
    try:
        return _login(payload, request, db)
    except HTTPException:
        raise  # expected outcomes (401/403/503), already logged
    except Exception as exc:
        # Unexpected failure (would otherwise be a bare 500): log the full traceback
        # to the console and to ldap_login.log.
        logger.exception("AUTH - unexpected error during login of %r", payload.username)
        _log_ldap_login(
            request, payload.username, "ERROR", f"unexpected {type(exc).__module__}.{type(exc).__name__}: {exc}", exc
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Login failed because of a server error ({type(exc).__name__}). See ldap_login.log for details.",
        ) from exc


def _login(payload: LoginRequest, request: Request, db: Session) -> dict:
    # Local accounts are verified here, never against AD.
    user = find_user(db, payload.username) if payload.username.strip() else None
    if user is not None and is_local(user):
        if not verify_password(payload.password, user.hashed_password):
            logger.warning("AUTH - local login failed for %s", user.username)
            raise _invalid()
        if not user.enabled:
            logger.warning("AUTH - login refused, %s is disabled", user.username)
            raise _disabled()
        return _session(user)

    # Everyone else must exist in our DB (added by an admin) AND in AD.
    username = ldap_service.normalize_username(payload.username)
    user = find_user(db, username) if username else None
    if user is None:
        logger.warning("AUTH - login refused, %s is not registered in the application", username)
        _log_ldap_login(request, username or payload.username, "FAILED", "not registered in the application")
        raise _invalid()
    if is_local(user):
        # e.g. "DEV\administrator": a local account must never be unlocked by an AD password.
        logger.warning("AUTH - %s is a local account; AD-style login refused", user.username)
        _log_ldap_login(request, payload.username, "FAILED", "local account, AD-style login refused")
        raise _invalid()
    try:
        ad_user = ldap_service.authenticate(username, payload.password)
    except ldap_service.LdapError as exc:
        logger.error("AUTH - AD unavailable during login of %s: %s", username, exc)
        _log_ldap_login(request, username, "ERROR", f"Active Directory unavailable: {exc}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Active Directory is unavailable. Try again later or contact the administrator.",
        ) from exc
    if ad_user is None:
        logger.warning("AUTH - AD rejected login for %s (wrong password, disabled or removed)", username)
        _log_ldap_login(request, username, "FAILED", "AD rejected credentials (wrong password, disabled or removed)")
        raise _invalid()
    if not user.enabled:
        logger.warning("AUTH - login refused, %s is disabled in the application", user.username)
        _log_ldap_login(request, user.username, "FAILED", "disabled in the application")
        raise _disabled()
    if ad_user.display_name and ad_user.display_name != user.display_name:
        user.display_name = ad_user.display_name
        db.commit()
    _log_ldap_login(request, user.username, "SUCCESS")
    return _session(user)


@router.get("/setup")
def setup_status(db: Session = Depends(get_db)) -> dict:
    return {"setup_required": setup_required(db)}


@router.post("/setup", status_code=201)
def create_first_admin(payload: SetupRequest, db: Session = Depends(get_db)) -> dict:
    """First-run setup: create the first (local) administrator. Only allowed while no users exist."""
    username = payload.username.strip()
    if not USERNAME_RE.fullmatch(username):
        raise HTTPException(
            status_code=422,
            detail="User name must be 3-64 characters: letters, digits, dot, dash or underscore.",
        )
    if len(payload.password) < MIN_PASSWORD_LENGTH:
        raise HTTPException(
            status_code=422, detail=f"Password must be at least {MIN_PASSWORD_LENGTH} characters."
        )
    with _setup_lock:  # two simultaneous first-run requests must not both create an admin
        if not setup_required(db):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Setup has already been completed.")
        user = User(
            username=username,
            hashed_password=hash_password(payload.password),
            is_admin=True,
            auth_source="local",
            display_name="Local administrator",
        )
        db.add(user)
        db.commit()
    logger.warning("ADMIN - first administrator %s created through first-run setup", username)
    return {"username": username, "is_admin": True}


def _session(user: User) -> dict:
    token = create_access_token(user.username, settings.JWT_EXPIRES_MINUTES)
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": settings.JWT_EXPIRES_MINUTES * 60,
        "username": user.username,
        "display_name": user.display_name,
        "is_admin": user.is_admin,
        "auth_required": settings.REQUIRE_AUTH or settings.REQUIRE_API_KEY,
    }


def _sso_refused(detail: str) -> JSONResponse:
    # Deliberately no WWW-Authenticate header: re-challenging after a failed
    # attempt makes browsers pop up a credentials dialog. The frontend falls
    # back to the login page instead.
    return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": detail})


def _split_principal(principal: str) -> tuple[str, str]:
    r"""'jdoe@DEV.TEAM.AE' or 'DEV\jdoe' -> ('jdoe', 'DEV.TEAM.AE' / 'DEV')."""
    if "\\" in principal:
        domain, name = principal.split("\\", 1)
    elif "@" in principal:
        name, domain = principal.rsplit("@", 1)
    else:
        name, domain = principal, ""
    return name.strip(), domain.strip().upper()


@router.get("/sso")
def windows_sso(request: Request, db: Session = Depends(get_db)):
    """Windows integrated sign-in (Kerberos via SPNEGO "Negotiate").

    1st call (no ticket)  -> 401 + WWW-Authenticate: Negotiate (browser attaches the ticket and retries)
    2nd call (ticket)     -> validate ticket, require the user in our DB AND enabled in AD -> session
    Anything else         -> 401 without a challenge, so the frontend shows the login page.
    """
    if not (settings.SSO_ENABLED and settings.LDAP_ENABLED):
        return _sso_refused("Windows sign-in is disabled.")
    header = request.headers.get("Authorization", "")
    if not header.lower().startswith("negotiate "):
        return JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content={"detail": "Windows credentials required."},
            headers={"WWW-Authenticate": "Negotiate"},
        )

    try:
        in_token = base64.b64decode(header.split(" ", 1)[1].strip(), validate=True)
        ctx = spnego.server(protocol="negotiate", service="HTTP")
        out_token = ctx.step(in_token)
    except (binascii.Error, SpnegoError) as exc:
        logger.warning("SSO - ticket rejected: %s", exc)
        return _sso_refused("Windows sign-in failed.")
    except Exception as exc:  # missing keytab / GSSAPI library, etc.
        logger.error("SSO - Kerberos acceptor unavailable: %s", exc)
        return _sso_refused("Windows sign-in is not available on this server.")
    if not ctx.complete:
        # NTLM fallback needs a connection-bound multi-leg exchange — only Kerberos is supported.
        logger.warning("SSO - incomplete handshake (browser offered NTLM instead of Kerberos?)")
        return _sso_refused("Windows sign-in failed (Kerberos ticket required).")

    username, domain = _split_principal(ctx.client_principal or "")
    try:
        allowed = set(settings.sso_domain_list) or ldap_service.directory_domains()
        if not username or domain not in allowed:
            logger.warning("SSO - principal %s is outside the allowed domains %s", ctx.client_principal, allowed)
            return _sso_refused("Windows account is not from an allowed domain.")
        user = find_user(db, username)
        if user is None or is_local(user):
            logger.warning("SSO - %s is not registered in the application", username)
            return _sso_refused("Windows account is not registered in the application.")
        ad_user = ldap_service.find_user(username)
    except ldap_service.LdapError as exc:
        logger.error("SSO - AD unavailable during sign-in of %s: %s", username, exc)
        return _sso_refused("Active Directory is unavailable.")
    if ad_user is None:
        logger.warning("SSO - %s is disabled or missing in AD", username)
        return _sso_refused("Windows account is disabled or missing in Active Directory.")
    if not user.enabled:
        logger.warning("SSO - %s is disabled in the application", username)
        return _sso_refused("This account is disabled. Contact the administrator.")
    if ad_user.display_name and ad_user.display_name != user.display_name:
        user.display_name = ad_user.display_name
        db.commit()

    logger.info("SSO - %s signed in with Windows credentials", user.username)
    headers = {"WWW-Authenticate": "Negotiate " + base64.b64encode(out_token).decode()} if out_token else None
    return JSONResponse(content=_session(user), headers=headers)


@router.get("/me")
def me(request: Request, db: Session = Depends(get_db)) -> dict:
    """Identity probe for the frontend auth guard.

    - When a valid login JWT / API key is present -> authenticated.
    - When no credential is passed but auth is off -> anonymous (allowed).
    - When no/expired credential is passed and auth is on -> authenticated=false.
    """
    auth_required = settings.REQUIRE_AUTH or settings.REQUIRE_API_KEY
    identity = current_identity(request, db)
    if identity is not None:
        return {
            "authenticated": True,
            "kind": identity["kind"],
            "username": identity["username"],
            "is_admin": bool(identity["is_admin"]),
            "auth_required": auth_required,
            "setup_required": False,
        }
    return {
        "authenticated": False if auth_required else True,
        "kind": None if auth_required else "anonymous",
        "username": None,
        "is_admin": False,
        "auth_required": auth_required,
        "setup_required": setup_required(db),
    }
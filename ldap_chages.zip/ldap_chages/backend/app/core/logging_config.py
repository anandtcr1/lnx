"""Logging setup: console + rotating local job log. Never logs document contents."""

import logging
import os
from logging.handlers import RotatingFileHandler

from app.core.config import settings

_configured = False


def configure_logging() -> None:
    global _configured
    if _configured:
        return
    level = logging.DEBUG if settings.is_development else logging.INFO
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    os.makedirs(settings.logs_path, exist_ok=True)
    job_logger = logging.getLogger("ocr.jobs")
    job_logger.setLevel(logging.INFO)
    handler = RotatingFileHandler(
        os.path.join(settings.logs_path, "ocr_jobs.log"),
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    handler.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
    job_logger.addHandler(handler)

    # Audit trail of every Active Directory (LDAP) login attempt. File only, never passwords.
    login_logger = logging.getLogger(LDAP_LOGIN_LOGGER)
    login_logger.setLevel(logging.INFO)
    login_logger.propagate = False
    login_handler = RotatingFileHandler(
        os.path.join(settings.logs_path, LDAP_LOGIN_LOG_FILE),
        maxBytes=10 * 1024 * 1024,
        backupCount=10,
        encoding="utf-8",
    )
    login_handler.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
    login_handler.setLevel(logging.INFO)
    login_logger.addHandler(login_handler)
    # LDAP diagnostics (bind rejections with AD's reason code, connection / search
    # errors with tracebacks) go to the same file as well as the console.
    logging.getLogger("ocr.ldap").addHandler(login_handler)
    _configured = True


LDAP_LOGIN_LOGGER = "ocr.auth.ldap_login"
LDAP_LOGIN_LOG_FILE = "ldap_login.log"


def job_logger() -> logging.Logger:
    return logging.getLogger("ocr.jobs")


def ldap_login_logger() -> logging.Logger:
    return logging.getLogger(LDAP_LOGIN_LOGGER)
